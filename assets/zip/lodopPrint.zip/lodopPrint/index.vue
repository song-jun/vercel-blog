<template>
  <w-modal :title='`预览${printType}打印模式`' :visible="show" width="794px" centered @ok="doPrint" okText="打印"
    @cancel="show = false">
    <div ref="printHtml">
      <div ref="header" v-if="printType != 'table'">
        <div :style="style">{{ title }}</div>
        <slot name="header">
          <w-row class="table-header" :style="styleItem">
            <w-col :span="8">
              <span class="table-header-item">单据日期:</span>
              <span></span>
            </w-col>
            <w-col :span="8">
              <span class="table-header-item">单据编号:</span>
              <span></span>
            </w-col>
            <w-col :span="8">
              <span class="table-header-item">单据编号:</span>
              <span></span>
            </w-col>
            <w-col :span="8">
              <span class="table-header-item">接收仓库:</span>
              <span></span>
            </w-col>
          </w-row>
        </slot>
      </div>
      <div ref="table">
        <template v-if="tableType != 'wpg' || printType == 'table'">
          <slot name="table">
            <CusTable ref="cusTable" v-bind="$attrs" :columns="columns" :dataSource="printInfo.list" :tfoot="tfoot">
              <template slot="tfoot">
                <slot name="tfoot"></slot>
              </template>
              <template slot="caption">
                <slot name="tableHeader"></slot>
              </template>
              <template slot="tableFooter">
                <slot name="tableFooter"></slot>
              </template>
              <template slot-scope="{ text, record, index }" v-for="(column, ind) in columns" :slot="column.dataIndex">
                <slot :name="column.dataIndex" :text="text" :index="index" :row="record" :column="column"
                  :record="record">
                  {{
                    column.customRender
                      ? column.customRender(text, record, index)
                      : text
                  }}
                </slot>
              </template>
            </CusTable>
          </slot>
        </template>
        <template v-else>
          <slot name="table">
            <w-table :dataSource="printInfo.list" :pagination="false" :rowKey="(record, index) => index" bordered
              :class="`printType${printType}`">
              <template v-if="printType == 'html'" slot="title" slot-scope="currentPageData">
                <div :style="flex">
                  <slot name="tableHeader">tableHeader</slot>

                </div>
              </template>
              <template v-if="printType == 'html'" slot="footer" slot-scope="currentPageData">
                <div :style="flex">
                  <slot name="tableFooter">tableFooter</slot>
                </div>
              </template>
              <w-table-column v-if="showIndex" :title="indexTitle || '序号'" width="80px" align="center">
                <template slot-scope="text, record, index">
                  {{ index + 1 }}
                </template>
              </w-table-column>
              <w-table-column v-for="column of columns" :key="column.dataIndex" :width="isFunction(column.width) ? column.width() : column.width || ''
                " :data-index="column.dataIndex" :align="column.align" :ellipsis="column.ellipsis || false"
                :fixed="column.fixed || false" :custom-render="column.customRender" :sorter="column.sorter"
                :sort-directions="column.sortDirections" :default-sort-order="column.defaultSortOrder">
                <slot v-if="!column.cusTitle" :name="`${column.dataIndex}Title`">
                  <span slot="title">{{
                    isFunction(column.title) ? column.title() : column.title
                    }}</span>
                </slot>
                <template slot-scope="text, record, index">
                  <slot :name="column.dataIndex" :text="text" :index="index" :row="record" :column="column"
                    :record="record">
                    {{ text }}
                  </slot>
                </template>
              </w-table-column>
            </w-table>
          </slot>
        </template>
      </div>
      <div class="footer-box" ref="footer" v-if="printType == 'html'" :style="styleItem">
        <slot name="footer">
          <w-row>
            <w-col :span="12">
              <span class="footer-item">制单人:</span>
              <span class="footer-item"></span>
            </w-col>
            <w-col :span="12">
              <span class="footer-item">审核人:</span>
              <span class="footer-item"></span>
            </w-col>
            <w-col :span="12">
              <span class="footer-item">部门负责人:</span>
              <span class="footer-item"></span>
            </w-col>
            <w-col :span="12">
              <span class="footer-item">分管领导:</span>
              <span class="footer-item"></span>
            </w-col>
          </w-row>
        </slot>
      </div>
    </div>
  </w-modal>
</template>

<script>
  import CusTable from "./cusTable";
  import { tableCss } from "./tableCss.js";
  import { getLodop } from "./lodop/LodopFuncs";
  let dataSource = [],
    printInfo = {};
  for (let index = 0; index < 100; index++) {
    let obj = {
      key: index,
      name: `test${index + 1}`,
      age: 32,
      address: "西湖区湖底公园1号",
    };
    dataSource.push(obj);
  }
  printInfo = {
    list: dataSource,
  };
  const columns = [
    {
      title: "姓名",
      dataIndex: "name",
      key: "name",
      scopedSlots: { customRender: "name" },
    },
    {
      title: "年龄",
      dataIndex: "age",
      key: "age",
      customRender: (text, record, index) => `customRender${index + 1}`,
      ellipsis: true,
    },
    {
      title: "住址",
      scopedSlots: { customRender: "address" },
      dataIndex: "address",
      key: "address",
    },
  ];
  export default {
    components: { CusTable },
    name: "lodopPrint",
    props: {
      showTable: {
        type: [Boolean, String],
        default: false,
      },
      // 自定义lodop脚本
      customFn: {
        type: Function,
        default: null,
      },
      // table的tfoot
      tfoot: {
        type: Boolean,
        default: false,
      },
      // 打印数据
      printInfo: {
        type: Object,
        default: () => printInfo,
      },
      // 是否展示序号
      showIndex: {
        type: Boolean,
        default: true,
      },
      // 序号
      indexTitle: {
        type: [Number, String],
        default: "序号",
      },
      // 打印标题
      title: {
        type: [Number, String],
        default: "工程材料",
      },
      // 距离顶部距离
      top: {
        type: [Number, String],
        default: 25,
      },
      // table类型
      tableType: {
        type: [String],
        default: "wpg",
      },
      // 打印类型
      printType: {
        type: [String],
        // html,table,all
        default: "",
      },
      // 距离底部距离
      bottom: {
        type: [Number, String],
        default: 80,
      },
      // table配置
      columns: {
        type: Array,
        default: () => columns,
      },
    },
    data() {
      return {
        dataSource,
        pages: 1,
        show: false,
        flex: {
          display: "flex",
          "justify-content": "space-around",
          alignItems: "center",
          'flex-wrap': 'wrap'
        },
        style: {
          "font-size": "25px",
          "text-align": "center",
          display: "flex",
          "align-items": "center",
          "justify-content": "space-around",
        },
        styleItem: {
          "font-size": "16px",
          "text-align": "center",
          display: "flex",
          "align-items": "center",
          "justify-content": "space-between",
        },
      };
    },
    watch: {
      printInfo: {
        handler(val) {
          if (val.list) {
            let countLength = val.list.length;
            if (countLength <= 11) {
              this.pages = 1;
            } else {
              this.pages = Math.ceil(countLength / this.row);
            }
          }
          console.log(`🚀printInfo数据`, val);
        },
        deep: true,
        immediate: true,
      },
      showTable: {
        handler(val) {
          this.show = val;
        },
        deep: true,
        immediate: true,
      },
    },
    mounted() { },
    methods: {
      doPrint() {
        if (!this.show) return this.show = true;
        let LODOP = getLodop();
        LODOP.PRINT_INIT(`${this.title}`);
        if (this.customFn) return this.customFn();
        let header,
          table,
          headerHeight = 0,
          footer;
        if (this.$refs.header)
          (header = this.$refs.header.innerHTML) &&
            (headerHeight = this.$refs.header.offsetHeight);
        if (this.$refs.table) table = this.$refs.table.innerHTML;
        if (this.$refs.footer) footer = this.$refs.footer.innerHTML;
        let printStr = `<style>${tableCss}</style>${header}${table}${footer}`;
        LODOP.SET_PRINT_PAGESIZE(1, "A4", ""); //设置纸张
        // (1px=1/96英寸）
        // 1 毫米(mm)=0.0393700787402 英寸
        // 1英寸 = 96px
        // 1英寸 ≈ 25.4mm
        // 1mm ≈ 3.78px
        // 1px ≈ 0.2645mm
        // 参数说明：
        // 1:其中前两个参数设置上边距和左边距分别为40px和40px(1px=1/96英寸）；
        // 2:关键字RightMargin和BottomMargin使后俩参数不再设置宽度高度，而分别设置右边距和下边距；
        // 3:计量单位可混合使用，可以是百分比，但注意控件内部是以px为基本单位，换算会有细微误差；
        // LODOP.ADD_PRINT_TABLE(40, 40, 'RightMargin:40', 'BottomMargin:227', printerTableTemplate);
        // LODOP.SET_PRINT_STYLEA(0, 'Offset2Top', -200); // 非第一页内容距离顶部偏移量
        switch (this.printType) {
          case "all":
            LODOP.ADD_PRINT_HTM(
              parseInt(this.top),
              "5%",
              "90%",
              headerHeight,
              header
            ); //打印html
            LODOP.SET_PRINT_STYLEA(0, "ItemType", 1); //设置1页眉2页脚，每页固定位置输出
            LODOP.SET_PRINT_STYLEA(0, "LinkedItem", 1); //设置页眉页脚，每页固定位置输出
            //打印table专用，table之外的元素会忽视
            // 参数说明：表格数据头(页头thead)在纸张内的上边距,表格数据头(页头thead)在纸张内的左边距,宽度,格数据体(tbody)区域的高度
            LODOP.ADD_PRINT_TABLE(
              headerHeight + parseInt(this.top),
              "5%",
              "90%",
              `BottomMargin:${this.bottom || 80}`,
              `<style>${tableCss}</style>${table}`
            );
            LODOP.SET_PRINT_STYLEA(0, "Vorient", 3);
            // 设置页脚仅在最后一页显示
            // LODOP.ADD_PRINT_HTM('80%', '5%', '90%', '90%', footer); //打印html
            // LODOP.SET_PRINT_STYLE('ItemType', 2); // 2 表示页脚，1 表示页眉
            // LODOP.SET_PRINT_STYLEA(0, 'PageIndex', 'Last'); // 表示页脚仅显示在最后一页
            LODOP.PREVIEW();
            break;
          case "table":
            headerHeight = this.$refs.cusTable.$refs.caption.offsetHeight;
            // LODOP.ADD_PRINT_TABLE(
            //   parseInt(this.top),
            //   "5%",
            //   "90%",
            //   "70%",
            //   printStr
            // ); //打印table专用，table之外的元素会忽视
            LODOP.ADD_PRINT_TABLE(
              parseInt(this.top),
              40,
              "RightMargin:40",
              `BottomMargin:${this.bottom || 80}`,
              printStr
            );
            LODOP.SET_PRINT_STYLEA(0, "Offset2Top", -headerHeight); // 非第一页内容距离顶部偏移量
            LODOP.SET_PRINT_STYLEA(0, "Vorient", 3);

            LODOP.PREVIEW();
            break;
          case "html":
            LODOP.ADD_PRINT_HTM(
              parseInt(this.top),
              40,
              "RightMargin:40",
              `BottomMargin:${this.bottom || 80}`,
              printStr
            ); //打印html
            LODOP.SET_PRINT_STYLEA(0, "Vorient", 3);
            LODOP.PREVIEW();
            // 打开打印机设计界面
            // LODOP.PRINTA();
            break;
          default:
            break;
        }
      },
      isFunction(fn) {
        return typeof fn === "function" ? true : false;
      },
      isObject(fn) {
        return typeof fn === "object" ? true : false;
      },
    },
  };
</script>
<style lang="less" scoped>

  .printTypetable,
  .printTypeall {
    /deep/ .wpg-table-title {
      display: none;
    }

    /deep/ .wpg-table-footer {
      display: none;
    }
  }

  /deep/ .wpg-modal-body {
    height: 700px;
    overflow-y: auto;
  }
</style>