## 通用打印组件封装，目的是提高前端开发表格的效率

表格 props 说明

```js
props: {
  // 自定义lodop脚本
  customFn: {
    type: Function,
    default: null,
  },
  // table的tfoot
  tfoot: {
    type: Boolean,
    default: false,
  },
  // 打印数据
  printInfo: {
    type: Object,
    default: () => printInfo
  },
  // 是否展示序号
  showIndex: {
    type: Boolean,
    default: true
  },
  // 序号
  indexTitle: {
    type: [Number, String],
    default: '序号'
  },
  // 打印标题
  title: {
    type: [Number, String],
    default: '工程材料'
  },
  // 距离顶部距离
  top: {
    type: [Number, String],
    default: 25
  },
  // 距离底部距离
  bottom: {
    type: [Number, String],
    default: 80,
  },
  // table类型
  tableType: {
    type: [String],
    default: "wpg",
  },
  // 打印类型
  printType: {
    type: [String],
    // html,table,all
    default: 'html'
  },
  // table配置
  columns: {
    type: Array,
    default: () => columns
  }
}
```

### columns支持table属性slot,与antdesgin table组件columns配置一致
