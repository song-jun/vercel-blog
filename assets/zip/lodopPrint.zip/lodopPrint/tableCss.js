export const tableCss = `
.wpg-table-wrapper {
  zoom: 1;
}

.wpg-table-wrapper::before,
.wpg-table-wrapper::after {
  display: table;
  content: '';
}

.wpg-table-wrapper::after {
  clear: both;
}

.wpg-table {
  box-sizing: border-box;
  margin: 0;
  padding: 0;
  color: #666666;
  font-size: 14px;
  font-variant: tabular-nums;
  line-height: 1.5;
  list-style: none;
  font-feature-settings: 'tnum';
  font-size: 12px;
  line-height: 20px;
  position: relative;
  clear: both;
}

.wpg-table-body {
  transition: opacity 0.3s;
}

.wpg-table-empty .wpg-table-body {
  overflow-x: auto !important;
  overflow-y: hidden !important;
}

.wpg-table table {
  width: 100%;
  text-align: left;
  border-collapse: separate;
  border-spacing: 0;
}

.wpg-table-layout-fixed table {
  table-layout: fixed;
}

.wpg-table-thead>tr>th {
  color: #6281a3;
  text-align: left;
  background: #f2f6fc;
  font-weight: normal;
  transition: background 0.3s ease;
}

.wpg-table-thead>tr>th[colspan]:not([colspan='1']) {
  text-align: center;
}

.wpg-table-thead>tr>th .wpgicon-filter,
.wpg-table-thead>tr>th .wpg-table-filter-icon {
  position: absolute;
  top: 0;
  right: 0;
  width: 28px;
  height: 100%;
  color: #87909f;
  font-size: 12px;
  text-align: center;
  cursor: pointer;
  transition: all 0.3s;
}

.wpg-table-thead>tr>th .wpgicon-filter::before,
.wpg-table-thead>tr>th .wpg-table-filter-icon::before {
  position: absolute;
  top: calc(50% - 5px);
  left: calc(50% - 7px);
}

.wpg-table-thead>tr>th .wpgicon-filter>svg,
.wpg-table-thead>tr>th .wpg-table-filter-icon>svg {
  position: absolute;
  top: 50%;
  left: 50%;
  margin-top: -5px;
  margin-left: -6px;
}

.wpg-table-thead>tr>th .wpg-table-filter-selected.wpgicon {
  color: #4285f4;
}

.wpg-table-thead>tr>th .wpg-table-column-sorter {
  display: table-cell;
  vertical-align: middle;
}

.wpg-table-thead>tr>th .wpg-table-column-sorter .wpg-table-column-sorter-inner {
  height: 1em;
  margin-top: 0.35em;
  margin-left: 0.57142857em;
  color: #87909f;
  line-height: 1em;
  text-align: center;
  transition: all 0.3s;
}

.wpg-table-thead>tr>th .wpg-table-column-sorter .wpg-table-column-sorter-inner .wpgicon.custom,
.wpg-table-thead>tr>th .wpg-table-column-sorter .wpg-table-column-sorter-inner .iconfont.custom {
  font-size: 14px !important;
}

.wpg-table-thead>tr>th .wpg-table-column-sorter .wpg-table-column-sorter-inner .wpgicon.custom.wpg-table-column-sorter-up,
.wpg-table-thead>tr>th .wpg-table-column-sorter .wpg-table-column-sorter-inner .iconfont.custom.wpg-table-column-sorter-up {
  margin-top: -0.25em;
}

.wpg-table-thead>tr>th .wpg-table-column-sorter .wpg-table-column-sorter-inner .wpg-table-column-sorter-up,
.wpg-table-thead>tr>th .wpg-table-column-sorter .wpg-table-column-sorter-inner .wpg-table-column-sorter-down {
  display: inline-block;
  font-size: 12px;
  transform: scale(0.91666667) rotate(0deg);
  display: block;
  height: 1em;
  line-height: 1em;
  transition: all 0.3s;
}

:root .wpg-table-thead>tr>th .wpg-table-column-sorter .wpg-table-column-sorter-inner .wpg-table-column-sorter-up,
:root .wpg-table-thead>tr>th .wpg-table-column-sorter .wpg-table-column-sorter-inner .wpg-table-column-sorter-down {
  font-size: 12px;
}

.wpg-table-thead>tr>th .wpg-table-column-sorter .wpg-table-column-sorter-inner .wpg-table-column-sorter-up.on,
.wpg-table-thead>tr>th .wpg-table-column-sorter .wpg-table-column-sorter-inner .wpg-table-column-sorter-down.on {
  color: #4285f4;
}

.wpg-table-thead>tr>th .wpg-table-column-sorter .wpg-table-column-sorter-inner-full .wpg-table-column-sorter-up,
.wpg-table-thead>tr>th .wpg-table-column-sorter .wpg-table-column-sorter-inner-full .wpg-table-column-sorter-down {
  height: 0.5em;
  line-height: 0.5em;
}

.wpg-table-thead>tr>th .wpg-table-column-sorter .wpg-table-column-sorter-inner-full .wpg-table-column-sorter-down {
  margin-top: 0.125em;
}

.wpg-table-thead>tr>th.wpg-table-column-has-actions {
  position: relative;
  background-clip: padding-box;
  /* stylelint-disable-next-line */
  -webkit-background-clip: border-box;
}

.wpg-table-thead>tr>th.wpg-table-column-has-actions.wpg-table-column-has-filters {
  padding-right: 30px !important;
}

.wpg-table-thead>tr>th.wpg-table-column-has-actions.wpg-table-column-has-filters .wpgicon-filter.wpg-table-filter-open,
.wpg-table-thead>tr>th.wpg-table-column-has-actions.wpg-table-column-has-filters .wpg-table-filter-icon.wpg-table-filter-open {
  color: #666666;
  background: #eaf1fb;
}

.wpg-table-thead>tr>th.wpg-table-column-has-actions.wpg-table-column-has-filters:hover .wpgicon-filter:hover,
.wpg-table-thead>tr>th.wpg-table-column-has-actions.wpg-table-column-has-filters:hover .wpg-table-filter-icon:hover {
  color: #666666;
  background: #eaf1fb;
}

.wpg-table-thead>tr>th.wpg-table-column-has-actions.wpg-table-column-has-filters:hover .wpgicon-filter:active,
.wpg-table-thead>tr>th.wpg-table-column-has-actions.wpg-table-column-has-filters:hover .wpg-table-filter-icon:active {
  color: #333333;
}

.wpg-table-thead>tr>th.wpg-table-column-has-actions.wpg-table-column-has-sorters {
  cursor: pointer;
}

.wpg-table-thead>tr>th.wpg-table-column-has-actions.wpg-table-column-has-sorters:hover {
  background: #eaf1fb;
}

.wpg-table-thead>tr>th.wpg-table-column-has-actions.wpg-table-column-has-sorters:hover .wpgicon-filter,
.wpg-table-thead>tr>th.wpg-table-column-has-actions.wpg-table-column-has-sorters:hover .wpg-table-filter-icon {
  background: #eaf1fb;
}

.wpg-table-thead>tr>th.wpg-table-column-has-actions.wpg-table-column-has-sorters:active .wpg-table-column-sorter-up:not(.on),
.wpg-table-thead>tr>th.wpg-table-column-has-actions.wpg-table-column-has-sorters:active .wpg-table-column-sorter-down:not(.on) {
  color: #666666;
}

.wpg-table-thead>tr>th .wpg-table-header-column {
  display: inline-block;
  max-width: 100%;
  vertical-align: top;
}

.wpg-table-thead>tr>th .wpg-table-header-column .wpg-table-column-sorters {
  display: table;
}

.wpg-table-thead>tr>th .wpg-table-header-column .wpg-table-column-sorters>.wpg-table-column-title {
  display: table-cell;
  vertical-align: middle;
}

.wpg-table-thead>tr>th .wpg-table-header-column .wpg-table-column-sorters>*:not(.wpg-table-column-sorter) {
  position: relative;
}

.wpg-table-thead>tr>th .wpg-table-header-column .wpg-table-column-sorters::before {
  position: absolute;
  top: 0;
  right: 0;
  bottom: 0;
  left: 0;
  background: transparent;
  transition: all 0.3s;
  content: '';
}

.wpg-table-thead>tr>th .wpg-table-header-column .wpg-table-column-sorters:hover::before {
  background: #eaf1fb;
}

.wpg-table-thead>tr>th.wpg-table-column-has-sorters {
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
}

.wpg-table-thead>tr:not(:last-child)>th[colspan] {
  border-bottom: 0;
}

.wpg-table-tbody>tr>td {
  transition: background 0.3s;
}

.wpg-table-tbody>.wpg-table-row.even {
  background-color: #f9fafb;
}

.wpg-table-thead>tr.wpg-table-row-hover:not(.wpg-table-expanded-row):not(.wpg-table-row-selected)>td,
.wpg-table-tbody>tr.wpg-table-row-hover:not(.wpg-table-expanded-row):not(.wpg-table-row-selected)>td,
.wpg-table-thead>tr:hover:not(.wpg-table-expanded-row):not(.wpg-table-row-selected)>td,
.wpg-table-tbody>tr:hover:not(.wpg-table-expanded-row):not(.wpg-table-row-selected)>td {
  background: #eaf1fb;
}

.wpg-table-thead>tr.wpg-table-row-selected>td.wpg-table-column-sort,
.wpg-table-tbody>tr.wpg-table-row-selected>td.wpg-table-column-sort {
  background: #eaf1fb;
}

.wpg-table-thead>tr:hover.wpg-table-row-selected>td,
.wpg-table-tbody>tr:hover.wpg-table-row-selected>td {
  background: #eaf1fb;
}

.wpg-table-thead>tr:hover.wpg-table-row-selected>td.wpg-table-column-sort,
.wpg-table-tbody>tr:hover.wpg-table-row-selected>td.wpg-table-column-sort {
  background: #eaf1fb;
}

.wpg-table-thead>tr:hover {
  background: none;
}

.wpg-table-footer {
  position: relative;
  padding: 10px 16px;
  color: #333333;
  background: #f7faff;
  border-top: 1px solid #dee2e7;
}

.wpg-table-footer::before {
  position: absolute;
  top: -1px;
  left: 0;
  width: 100%;
  height: 1px;
  background: #f7faff;
  content: '';
}

.wpg-table.wpg-table-bordered .wpg-table-footer {
  border: 1px solid #dee2e7;
}

.wpg-table-title {
  position: relative;
  top: 1px;
  padding: 10px 0;
}

.wpg-table.wpg-table-bordered .wpg-table-title {
  padding-right: 16px;
  padding-left: 16px;
  border: 1px solid #dee2e7;
}

.wpg-table-title+.wpg-table-content {
  position: relative;
}

.wpg-table-without-column-header .wpg-table-title+.wpg-table-content,
.wpg-table-without-column-header table {
  border-radius: 0;
}

.wpg-table-without-column-header.wpg-table-bordered.wpg-table-empty .wpg-table-placeholder {
  border-top: 1px solid #dee2e7;
}

.wpg-table-tbody>tr.wpg-table-row-selected td {
  color: inherit;
  background: #eaf1fb;
}

.wpg-table-thead>tr>th.wpg-table-column-sort {
  background: #f2f6fc;
}

.wpg-table-thead>tr>th {
  padding: 10px 16px;
  overflow-wrap: break-word;
}

.wpg-table-tbody>tr>td {
  padding: 8px 16px;
  overflow-wrap: break-word;
  color: #333333;
}

.wpg-table-expand-icon-th,
.wpg-table-row-expand-icon-cell {
  width: 50px;
  min-width: 50px;
  text-align: center;
}

.wpg-table-header {
  overflow: hidden;
  background: #f2f6fc;
}

.wpg-table-loading {
  position: relative;
}

.wpg-table-loading .wpg-table-body {
  background: #fff;
  opacity: 0.5;
}

.wpg-table-loading .wpg-table-spin-holder {
  position: absolute;
  top: 50%;
  left: 50%;
  height: 20px;
  margin-left: -30px;
  line-height: 20px;
}

.wpg-table-loading .wpg-table-with-pagination {
  margin-top: -20px;
}

.wpg-table-loading .wpg-table-without-pagination {
  margin-top: 10px;
}

.wpg-table-bordered .wpg-table-thead>tr>th,
.wpg-table-bordered .wpg-table-tbody>tr>td {
  border-bottom: 1px solid #dee2e7;
}

.wpg-table-bordered .wpg-table-header>table,
.wpg-table-bordered .wpg-table-body>table,
.wpg-table-bordered .wpg-table-fixed-left table,
.wpg-table-bordered .wpg-table-fixed-right table {
  border: 1px solid #dee2e7;
  border-right: 0;
  border-bottom: 0;
}

.wpg-table-bordered.wpg-table-empty .wpg-table-placeholder {
  border: 1px solid #dee2e7;
}

.wpg-table-bordered.wpg-table-fixed-header .wpg-table-header>table {
  border-bottom: 0;
}

.wpg-table-bordered.wpg-table-fixed-header .wpg-table-body>table {
  border-top-left-radius: 0;
  border-top-right-radius: 0;
}

.wpg-table-bordered.wpg-table-fixed-header .wpg-table-header+.wpg-table-body>table,
.wpg-table-bordered.wpg-table-fixed-header .wpg-table-body-inner>table {
  border-top: 0;
}

.wpg-table-bordered .wpg-table-thead>tr:not(:last-child)>th {
  border-bottom: 1px solid #dee2e7;
}

.wpg-table-bordered .wpg-table-thead>tr>th,
.wpg-table-bordered .wpg-table-tbody>tr>td {
  border-right: 1px solid #dee2e7;
}

.wpg-table-placeholder {
  position: relative;
  z-index: 1;
  margin-top: -1px;
  padding: 10px 16px;
  color: #c0c0c0;
  text-align: center;
  background: #fff;
}

.wpg-table-pagination.wpg-pagination {
  float: right;
  margin: 16px 0;
}

.wpg-table-filter-dropdown {
  position: relative;
  min-width: 96px;
  margin-left: -8px;
  background: #fff;
  border-radius: 4px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.wpg-table-filter-dropdown .wpg-dropdown-menu {
  max-height: calc(100vh - 130px);
  overflow-x: hidden;
  border: 0;
  border-radius: 4px 4px 0 0;
  box-shadow: none;
}

.wpg-table-filter-dropdown .wpg-dropdown-menu-item>label+span {
  padding-right: 0;
}

.wpg-table-filter-dropdown .wpg-dropdown-menu-sub {
  border-radius: 4px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.wpg-table-filter-dropdown .wpg-dropdown-menu .wpg-dropdown-submenu-contain-selected .wpg-dropdown-menu-submenu-title::after {
  color: #4285f4;
  font-weight: bold;
  text-shadow: 0 0 2px #f1f6fd;
}

.wpg-table-filter-dropdown .wpg-dropdown-menu-item {
  overflow: hidden;
}

.wpg-table-filter-dropdown>.wpg-dropdown-menu>.wpg-dropdown-menu-item:last-child,
.wpg-table-filter-dropdown>.wpg-dropdown-menu>.wpg-dropdown-menu-submenu:last-child .wpg-dropdown-menu-submenu-title {
  border-radius: 0;
}

.wpg-table-filter-dropdown-btns {
  padding: 7px 8px;
  overflow: hidden;
  border-top: 1px solid #dee2e7;
}

.wpg-table-filter-dropdown-link {
  color: #4285f4;
}

.wpg-table-filter-dropdown-link:hover {
  color: #71a3f8;
}

.wpg-table-filter-dropdown-link:active {
  color: #1353b3;
}

.wpg-table-filter-dropdown-link.confirm {
  float: left;
}

.wpg-table-filter-dropdown-link.clear {
  float: right;
}

.wpg-table-selection {
  white-space: nowrap;
}

.wpg-table-selection-column {
  line-height: 1;
}

.wpg-table-selection-column .wpg-checkbox {
  top: 0;
}

.wpg-table-selection-select-all-custom {
  margin-right: 4px !important;
}

.wpg-table-selection .wpgicon-down {
  color: #87909f;
  transition: all 0.3s;
}

.wpg-table-selection-menu {
  min-width: 96px;
  margin-top: 5px;
  margin-left: -30px;
  background: #fff;
  border-radius: 4px;
  box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
}

.wpg-table-selection-menu .wpg-action-down {
  color: #87909f;
}

.wpg-table-selection-down {
  display: inline-block;
  padding: 0;
  line-height: 1;
  cursor: pointer;
}

.wpg-table-selection-down:hover .wpgicon-down {
  color: rgba(0, 0, 0, 0.6);
}

.wpg-table-row-expand-icon {
  color: #4285f4;
  text-decoration: none;
  cursor: pointer;
  transition: color 0.3s;
  display: inline-block;
  width: 17px;
  height: 17px;
  color: inherit;
  line-height: 13px;
  text-align: center;
  background: #fff;
  border: 1px solid #dee2e7;
  border-radius: 2px;
  outline: none;
  transition: all 0.3s;
  -webkit-user-select: none;
  -moz-user-select: none;
  user-select: none;
}

.wpg-table-row-expand-icon:focus,
.wpg-table-row-expand-icon:hover {
  color: #71a3f8;
}

.wpg-table-row-expand-icon:active {
  color: #1353b3;
}

.wpg-table-row-expand-icon:focus,
.wpg-table-row-expand-icon:hover,
.wpg-table-row-expand-icon:active {
  border-color: currentColor;
}

.wpg-table-row-expanded::after {
  content: '-';
}

.wpg-table-row-collapsed::after {
  content: '+';
}

.wpg-table-row-spaced {
  visibility: hidden;
}

.wpg-table-row-spaced::after {
  content: '.';
}

.wpg-table-row-cell-ellipsis,
.wpg-table-row-cell-ellipsis .wpg-table-column-title {
  overflow: hidden;
  white-space: nowrap;
  text-overflow: ellipsis;
}

.wpg-table-row-cell-ellipsis .wpg-table-column-title {
  display: block;
}

.wpg-table-row-cell-break-word {
  word-wrap: break-word;
  word-break: break-word;
}

tr.wpg-table-expanded-row,
tr.wpg-table-expanded-row:hover {
  background: inherit;
}

tr.wpg-table-expanded-row td>.wpg-table-wrapper {
  margin: -10px -16px -11px;
}

tr.wpg-table-expanded-row td {
  color: #999999;
}

.wpg-table .wpg-table-row-indent+.wpg-table-row-expand-icon,
.wpg-table .wpg-table-row-indent+.wpgicon {
  margin-right: 8px;
}

.wpg-table-scroll {
  overflow: auto;
  overflow-x: hidden;
}

.wpg-table-scroll table {
  min-width: 100%;
}

.wpg-table-scroll table .wpg-table-fixed-columns-in-body:not([colspan]) {
  color: transparent;
}

.wpg-table-scroll table .wpg-table-fixed-columns-in-body:not([colspan])>* {
  visibility: hidden;
}

.wpg-table-body-inner {
  height: 100%;
}

.wpg-table-fixed-header>.wpg-table-content>.wpg-table-scroll>.wpg-table-body {
  position: relative;
  background: #fff;
}

.wpg-table-fixed-header .wpg-table-body-inner {
  overflow: scroll;
}

.wpg-table-fixed-header .wpg-table-scroll .wpg-table-header {
  margin-bottom: -20px;
  padding-bottom: 20px;
  overflow: scroll;
  opacity: 0.9999;
}

.wpg-table-fixed-header .wpg-table-scroll .wpg-table-header::-webkit-scrollbar {
  border: 1px solid #dee2e7;
  border-width: 0 0 1px 0;
}

.wpg-table-hide-scrollbar {
  scrollbar-color: transparent transparent;
  min-width: unset;
}

.wpg-table-hide-scrollbar::-webkit-scrollbar {
  min-width: inherit;
  background-color: transparent;
}

.wpg-table-bordered.wpg-table-fixed-header .wpg-table-scroll .wpg-table-header::-webkit-scrollbar {
  border: 1px solid #dee2e7;
  border-width: 1px 1px 1px 0;
}

.wpg-table-bordered.wpg-table-fixed-header .wpg-table-scroll .wpg-table-header.wpg-table-hide-scrollbar .wpg-table-thead>tr:only-child>th:last-child {
  border-right-color: transparent;
}

.wpg-table-fixed-left,
.wpg-table-fixed-right {
  position: absolute;
  top: 0;
  z-index: 1;
  overflow: hidden;
  border-radius: 0;
  transition: box-shadow 0.3s ease;
}

.wpg-table-fixed-left table,
.wpg-table-fixed-right table {
  width: auto;
  background: #fff;
}

.wpg-table-fixed-header .wpg-table-fixed-left .wpg-table-body-outer .wpg-table-fixed,
.wpg-table-fixed-header .wpg-table-fixed-right .wpg-table-body-outer .wpg-table-fixed {
  border-radius: 0;
}

.wpg-table-fixed-left {
  left: 0;
  box-shadow: 6px 0 6px -4px rgba(0, 0, 0, 0.1);
}

.wpg-table-fixed-left .wpg-table-header {
  overflow-y: hidden;
}

.wpg-table-fixed-left .wpg-table-body-inner {
  margin-right: -20px;
  padding-right: 20px;
}

.wpg-table-fixed-header .wpg-table-fixed-left .wpg-table-body-inner {
  padding-right: 0;
}

.wpg-table-fixed-left .wpg-table-thead>tr>th:last-child {
  border-top-right-radius: 0;
}

.wpg-table-fixed-right {
  right: 0;
  box-shadow: -6px 0 6px -4px rgba(0, 0, 0, 0.1);
}

.wpg-table-fixed-right .wpg-table-expanded-row {
  color: transparent;
  pointer-events: none;
}

.wpg-table-fixed-right .wpg-table-thead>tr>th:first-child {
  border-top-left-radius: 0;
}

.wpg-table.wpg-table-scroll-position-left .wpg-table-fixed-left {
  box-shadow: none;
}

.wpg-table.wpg-table-scroll-position-right .wpg-table-fixed-right {
  box-shadow: none;
}

.wpg-table colgroup>col.wpg-table-selection-col {
  width: 60px;
}

.wpg-table-thead>tr>th.wpg-table-selection-column-custom .wpg-table-selection {
  margin-right: -15px;
}

.wpg-table-thead>tr>th.wpg-table-selection-column,
.wpg-table-tbody>tr>td.wpg-table-selection-column {
  text-align: center;
}

.wpg-table-thead>tr>th.wpg-table-selection-column .wpg-radio-wrapper,
.wpg-table-tbody>tr>td.wpg-table-selection-column .wpg-radio-wrapper {
  margin-right: 0;
}

.wpg-table-row[class*='wpg-table-row-level-0'] .wpg-table-selection-column>span {
  display: inline-block;
}

.wpg-table-filter-dropdown .wpg-checkbox-wrapper+span,
.wpg-table-filter-dropdown-submenu .wpg-checkbox-wrapper+span {
  padding-left: 8px;
}

/**
* Another fix of Firefox:
*/
@supports (-moz-appearance: meterbar) {
  .wpg-table-thead>tr>th.wpg-table-column-has-actions {
    background-clip: padding-box;
  }
}

.wpg-table-middle>.wpg-table-title,
.wpg-table-middle>.wpg-table-content>.wpg-table-footer {
  padding: 8px 8px;
}

.wpg-table-middle>.wpg-table-content>.wpg-table-header>table>.wpg-table-thead>tr>th,
.wpg-table-middle>.wpg-table-content>.wpg-table-body>table>.wpg-table-thead>tr>th,
.wpg-table-middle>.wpg-table-content>.wpg-table-scroll>.wpg-table-header>table>.wpg-table-thead>tr>th,
.wpg-table-middle>.wpg-table-content>.wpg-table-scroll>.wpg-table-body>table>.wpg-table-thead>tr>th,
.wpg-table-middle>.wpg-table-content>.wpg-table-fixed-left>.wpg-table-header>table>.wpg-table-thead>tr>th,
.wpg-table-middle>.wpg-table-content>.wpg-table-fixed-right>.wpg-table-header>table>.wpg-table-thead>tr>th,
.wpg-table-middle>.wpg-table-content>.wpg-table-fixed-left>.wpg-table-body-outer>.wpg-table-body-inner>table>.wpg-table-thead>tr>th,
.wpg-table-middle>.wpg-table-content>.wpg-table-fixed-right>.wpg-table-body-outer>.wpg-table-body-inner>table>.wpg-table-thead>tr>th,
.wpg-table-middle>.wpg-table-content>.wpg-table-header>table>.wpg-table-tbody>tr>td,
.wpg-table-middle>.wpg-table-content>.wpg-table-body>table>.wpg-table-tbody>tr>td,
.wpg-table-middle>.wpg-table-content>.wpg-table-scroll>.wpg-table-header>table>.wpg-table-tbody>tr>td,
.wpg-table-middle>.wpg-table-content>.wpg-table-scroll>.wpg-table-body>table>.wpg-table-tbody>tr>td,
.wpg-table-middle>.wpg-table-content>.wpg-table-fixed-left>.wpg-table-header>table>.wpg-table-tbody>tr>td,
.wpg-table-middle>.wpg-table-content>.wpg-table-fixed-right>.wpg-table-header>table>.wpg-table-tbody>tr>td,
.wpg-table-middle>.wpg-table-content>.wpg-table-fixed-left>.wpg-table-body-outer>.wpg-table-body-inner>table>.wpg-table-tbody>tr>td,
.wpg-table-middle>.wpg-table-content>.wpg-table-fixed-right>.wpg-table-body-outer>.wpg-table-body-inner>table>.wpg-table-tbody>tr>td {
  padding: 8px 8px;
}

.wpg-table-middle tr.wpg-table-expanded-row td>.wpg-table-wrapper {
  margin: -8px -8px -9px;
}

.wpg-table-small>.wpg-table-title,
.wpg-table-small>.wpg-table-content>.wpg-table-footer {
  padding: 5px 8px;
}

.wpg-table-small>.wpg-table-title {
  top: 0;
}

.wpg-table-small>.wpg-table-content>.wpg-table-header>table>.wpg-table-thead>tr>th,
.wpg-table-small>.wpg-table-content>.wpg-table-body>table>.wpg-table-thead>tr>th,
.wpg-table-small>.wpg-table-content>.wpg-table-scroll>.wpg-table-header>table>.wpg-table-thead>tr>th,
.wpg-table-small>.wpg-table-content>.wpg-table-scroll>.wpg-table-body>table>.wpg-table-thead>tr>th,
.wpg-table-small>.wpg-table-content>.wpg-table-fixed-left>.wpg-table-header>table>.wpg-table-thead>tr>th,
.wpg-table-small>.wpg-table-content>.wpg-table-fixed-right>.wpg-table-header>table>.wpg-table-thead>tr>th,
.wpg-table-small>.wpg-table-content>.wpg-table-fixed-left>.wpg-table-body-outer>.wpg-table-body-inner>table>.wpg-table-thead>tr>th,
.wpg-table-small>.wpg-table-content>.wpg-table-fixed-right>.wpg-table-body-outer>.wpg-table-body-inner>table>.wpg-table-thead>tr>th,
.wpg-table-small>.wpg-table-content>.wpg-table-header>table>.wpg-table-tbody>tr>td,
.wpg-table-small>.wpg-table-content>.wpg-table-body>table>.wpg-table-tbody>tr>td,
.wpg-table-small>.wpg-table-content>.wpg-table-scroll>.wpg-table-header>table>.wpg-table-tbody>tr>td,
.wpg-table-small>.wpg-table-content>.wpg-table-scroll>.wpg-table-body>table>.wpg-table-tbody>tr>td,
.wpg-table-small>.wpg-table-content>.wpg-table-fixed-left>.wpg-table-header>table>.wpg-table-tbody>tr>td,
.wpg-table-small>.wpg-table-content>.wpg-table-fixed-right>.wpg-table-header>table>.wpg-table-tbody>tr>td,
.wpg-table-small>.wpg-table-content>.wpg-table-fixed-left>.wpg-table-body-outer>.wpg-table-body-inner>table>.wpg-table-tbody>tr>td,
.wpg-table-small>.wpg-table-content>.wpg-table-fixed-right>.wpg-table-body-outer>.wpg-table-body-inner>table>.wpg-table-tbody>tr>td {
  padding: 5px 8px;
}

.wpg-table-small>.wpg-table-content>.wpg-table-scroll>.wpg-table-header>table,
.wpg-table-small>.wpg-table-content>.wpg-table-scroll>.wpg-table-body>table,
.wpg-table-small>.wpg-table-content>.wpg-table-fixed-left>.wpg-table-header>table,
.wpg-table-small>.wpg-table-content>.wpg-table-fixed-right>.wpg-table-header>table,
.wpg-table-small>.wpg-table-content>.wpg-table-fixed-left>.wpg-table-body-outer>.wpg-table-body-inner>table,
.wpg-table-small>.wpg-table-content>.wpg-table-fixed-right>.wpg-table-body-outer>.wpg-table-body-inner>table {
  padding: 0;
}

.wpg-table-small tr.wpg-table-expanded-row td>.wpg-table-wrapper {
  margin: -5px -8px -6px;
}
table td{
  overflow: auto!important;
  white-space: unset!important;
}
`;
