<template>
  <div class="print-content">
    <table
      width="100%"
      border="1"
      cellspacing="0"
      cellpadding="0"
      :style="tableStyle"
    >
      <caption ref="caption" style="padding: 0; caption-side: top; width: 100%">
        <div :style="captionTop">
          <font face="宋体" size="6"
            ><b>{{ title }}</b></font
          >
        </div>
        <div :style="captionContent">
          <slot name="caption"></slot>
        </div>
      </caption>

      <thead>
        <tr>
          <td
            v-for="(column, index) in columns"
            :key="index"
            :align="column.align || 'center'"
            valign="middle"
            class="label-text"
            :style="tdStyle"
          >
            <slot>{{ column.title }}</slot>
          </td>
        </tr>
      </thead>
      <tbody>
        <tr v-for="(item, ind) in dataSource" :key="ind">
          <td
            v-for="(column, index) in columns"
            :key="index"
            :align="column.align || 'center'"
            valign="middle"
            class="label-text"
            :style="tdStyle"
          >
            <slot
              :name="column.dataIndex"
              :text="item[column.dataIndex]"
              :index="ind"
              :row="item"
              :column="column"
              :record="item"
            >
              {{ item[column.dataIndex] }}
            </slot>
          </td>
        </tr>
        <tr>
          <td :style="tdStyle" :colspan="columns.length">
            <div :style="flex">
              <slot name="tableFooter">tableFooter</slot>
            </div>
          </td>
        </tr>
      </tbody>
      <tfoot :style="footStyle" v-if="tfoot">
        <tr>
          <td :style="tdStyle" :colspan="columns.length">
            <div :style="flex">
              <slot name="tfoot">tfoot</slot>
            </div>
          </td>
        </tr>
      </tfoot>
    </table>
  </div>
</template>

<script>
export default {
  name: "cusTable",
  props: {
    // table的tfoot
    tfoot: {
      type: Boolean,
      default: false,
    },
    // 打印数据
    dataSource: {
      type: Array,
      default: () => [],
    }, // 打印标题
    title: {
      type: [Number, String],
      default: "工程材料",
    },
    // table配置
    columns: {
      type: Array,
      default: () => [],
    },
  },
  data() {
    return {
      titleStyle: {
        fontSize: "30px",
        color: "#333",
        fontWeight: "bold",
        lineHeight: "48px",
        fontFamily: "'Courier New', Courier, monospace",
        textAlign: "center",
      },
      captionTop: {
        width: "100%",
        border: "1px solid #000",
        "border-bottom": "none",
        "border-collapse": "separate",
        "font-size": "2.5em",
        display: "flex",
        "justify-content": "space-around",
        alignItems: "center",
      },
      captionContent: {
        width: "100%",
        border: "1px solid #000",
        "border-bottom": "none",
        "border-collapse": "separate",
        "font-size": "1.5em",
        display: "flex",
        "justify-content": "space-around",
        'flex-wrap': 'wrap',
        alignItems: "center",
      },
      flex: {
        display: "flex",
        "justify-content": "space-around",
        alignItems: "center",
        'flex-wrap': 'wrap'
      },
      spanStyle: {
        display: "inline-block",
        width: "40%",
        lineHeight: "36px",
      },
      tdStyle: {
        borderRight: "1px solid #333",
        borderBottom: "1px solid #333",
        height: "32px",
        padding: "0 4px",
        verticalAlign: "middle",
        wordWrap: "break-word",
        wordBreak: "break-all",
        textAlign: "center",
      },
      tableStyle: {
        border: "1px solid #333",
        tableLayout: "fixed",
        borderRight: "0px",
        borderBottom: "0px",
        marginTop: "6px",
      },
      footStyle: {
        border: "1px solid #333",
        borderTop: 0,
      },
      footerSpan: {
        width: "25%",
        display: "inline-block",
      },
      footerSpanLabel: { display: "inline-block" },
      footerSpanText: {
        minWidth: "60%",
        borderBottom: "1px solid #333",
        display: "inline-block",
      },
    };
  },
  computed: {},
  watch: {},
  mounted() {
    console.log("$attrs", this.$attrs);
  },
  methods: {},
};
</script>
