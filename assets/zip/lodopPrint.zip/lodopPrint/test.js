let dataSource = [],
  printInfo = {};
for (let index = 0; index < 80; index++) {
  let obj = {
    key: index,
    name: `test${index + 1}`,
    nickname: `nickname${index + 1}`,
    age: 32,
    address: "西湖区湖底公园1号",
  };
  dataSource.push(obj);
}
printInfo = {
  list: dataSource,
};
const columns = [
  {
    title: "姓名",
    dataIndex: "name",
    key: "name",
    scopedSlots: { customRender: "name" },
  },
  {
    title: "年龄",
    dataIndex: "age",
    key: "age",
    customRender: (text, record, index) => {
      return `customRender${index + 1}${record.key}`;
    },
    ellipsis: true,
  },
  {
    title: "住址",
    scopedSlots: { customRender: "address" },
    dataIndex: "address",
    key: "address",
  },
  {
    title: "昵称",
    dataIndex: "nickname",
    key: "nickname",
  },
];

export const mocdData = {
  printInfo,
  columns,
};
