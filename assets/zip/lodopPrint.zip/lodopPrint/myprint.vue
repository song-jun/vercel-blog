<template>
  <div class="print-root">
    <w-dropdown-button @click="handleButtonClick">
      预览
      <w-menu slot="overlay" @click="handleMenuClick">
        <w-menu-item key="table"> <w-icon type="user" />table模式</w-menu-item>
        <w-menu-item key="html"> <w-icon type="user" />html模式</w-menu-item>
        <w-menu-item key="all"> <w-icon type="user" />all模式</w-menu-item>
      </w-menu>
    </w-dropdown-button>
    <myprint
      ref="myprint"
      title="测试封装print"
      :printType="printType"
      :customFn="null"
      showTable
      top="40"
      bottom="110"
      tableType="wpg"
      :print-info="printInfo"
      :columns="columns"
      v-bind="$attrs"
      :tfoot="true"
    >
      <!-- 自定义table -->
      <!-- <template slot="table" slot-scope="text, record, index"> <div>table</div> </template> -->
      <!-- 插槽 -->
      <template slot="address" slot-scope="{ text, record, index }">
        {{ index }}|{{ text }}
      </template>
      <!-- 插槽 -->
      <template slot="name" slot-scope="{ text, record, index }">
        {{ index }}|{{ text }}
      </template>
      <!-- 头部 -->
      <template slot="header" slot-scope="text, record, index">
        <div>头部</div>
      </template>
      <!-- 尾部 -->
      <template slot="footer" slot-scope="text, record, index">
        <div>尾部</div>
      </template>
      <!-- 页脚 -->
      <template slot="tfoot" slot-scope="text, record, index">
        <div>页脚</div>
      </template>
      <!-- table头部 -->
      <template slot="tableHeader" slot-scope="text, record, index">
        <div>table头部</div>
        <div>table头部</div>
        <div>table头部</div>
        <div>table头部</div>
        <div>table头部</div>
        <div>table头部</div>
        <div>table头部</div>
        <div>table头部</div>
        <div>table头部</div>
        <div>table头部</div>
      </template>
      <!-- table尾部 -->
      <template slot="tableFooter" slot-scope="text, record, index">
        <div>table尾部</div>
        <div>table尾部</div>
        <div>table尾部</div>
        <div>table尾部</div>
        <div>table尾部</div>
        <div>table尾部</div>
        <div>table尾部</div>
        <div>table尾部</div>
        <div>table尾部</div>
        <div>table尾部</div>
        <div>table尾部</div>
        <div>table尾部</div>
        <div>table尾部</div>
        <div>table尾部</div>
        <div>table尾部</div>
        <div>table尾部</div>
      </template>
    </myprint>
  </div>
</template>

<script>
import myprint from "./index.vue";
import { mocdData } from "./test";

export default {
  components: { myprint },
  data() {
    return {
      printInfo: mocdData.printInfo,
      columns: mocdData.columns,
      printType: "html",
    };
  },
  mounted() {},
  methods: {
    handleButtonClick(e) {
      this.$refs.myprint.show = true;
    },
    handleMenuClick(e) {
      this.printType = e.key;
      this.$refs.myprint.show = true;
    },
    doPrint() {
      this.$refs.myprint.doPrint();
    },
    printJs() {
      console.log("🚀自定义lodop打印Js");
    },
  },
};
</script>
