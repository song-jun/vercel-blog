<template>
  <w-popover trigger="click" placement="bottom">
    <w-button type="link" style="padding-left: 0" icon="filter"></w-button>
    <template slot="content">
      <draggable
        :options="{ animation: 60, handle: '.draghandle' }"
        v-model="columnIndexs"
        chosenClass="active"
        animation="500"
        @end="dragEnd"
      >
        <div v-for="item in filterCheckColumns" class="checkColumns" :key="item.dataIndex">
          <w-checkbox v-model="item.checked" @change="columnsHandleChange($event, item.dataIndex)">
            {{ isFunction(item.title) ? item.title() : item.title }}
          </w-checkbox>
          <w-button
            style="width: 24px; height: 24px"
            type="dashed"
            icon="drag"
            size="small"
            class="draghandle"
          ></w-button>
        </div>
      </draggable>
    </template>
  </w-popover>
</template>

<script>
import draggable from "vuedraggable";

/**
 * @Description:
 * exclude 排除不用选择排序的列  比如 操作 传入 dataIndex数组
 * @date 2021/7/20
 */
import { isFunction } from "./utils/util";

export default {
  name: "CheckColumn",
  components: {
    draggable,
  },
  model: {
    prop: "columns",
    event: "changeColumns",
  },
  props: ["columns", "exclude"],
  data() {
    return {
      checkColumns: [],
      cacheColumns: [],
      hideColumns: [],
      columnIndexs: [],
      cacheColumnIndexs: [],
    };
  },
  watch: {
    columns: {
      handler(newV, oldV) {
        if (newV) {
          this.checkColumnsInit();
        }
      },
      immediate: true,
      deep: true,
    },
  },
  computed: {
    filterCheckColumns: function () {
      return this.checkColumns.filter((x) => !this.exclude.includes(x.dataIndex));
    },
    hideColumnIndexs() {
      return this.hideColumns.map((item) => item.dataIndex);
    },
  },
  mounted() {
    this.checkColumnsInit();
  },
  methods: {
    isFunction,
    dragEnd(e) {
      let index = 0;
      let columnIndexs = [];
      this.cacheColumnIndexs.forEach((item) => {
        if (this.columnIndexs.includes(item)) {
          columnIndexs.push(this.columnIndexs[index]);
          index++;
        } else {
          columnIndexs.push(item);
        }
      });
      this.cacheColumns = this.checkColumns = columnIndexs.map((item) => {
        return this.checkColumns.find((x) => x.dataIndex === item);
      });
      let columns = this.checkColumns;
      columns = columns.filter((item) => !this.hideColumnIndexs.includes(item.dataIndex));
      this.$emit("changeColumns", columns);
    },
    columnsHandleChange(data, column) {
      let arr = [];
      if (data.target.checked) {
        // 显示
        //查找隐藏的咧
        let index = this.hideColumns.findIndex((x) => x.dataIndex === column);
        let columnData = this.hideColumns[index];
        this.hideColumns.splice(index, 1);
        if (!columnData) return;
        // 反向思维 我们只需要知道哪些列需要显示即可   需要显示=已显示列+选择列
        arr = this.cacheColumns.filter((x) => {
          return this.columns.find((item) => item.dataIndex === x.dataIndex) || x.dataIndex === columnData.dataIndex;
        });
      } else {
        // 如果是隐藏
        arr = this.columns.filter((x) => {
          if (x.dataIndex === column) {
            this.hideColumns.push(x);
            return false;
          }
          return true;
        });
      }

      this.$emit("changeColumns", arr);
    },
    checkColumnsInit() {
      this.checkColumns = this.columns.map((item) => {
        return {
          ...item,
          checked: true,
        };
      });
      this.columnIndexs = this.columns.filter((x) => !this.exclude.includes(x.dataIndex)).map((x) => x.dataIndex);
      // this.columnIndexs = this.columns.map((x) => x.dataIndex);
      this.cacheColumnIndexs = this.columns.map((x) => x.dataIndex);
      this.cacheColumns = [...this.checkColumns];
    },
  },
};
</script>

<style lang="less" scoped>
.checkColumns {
  padding: 5px 0;
  display: flex;
  align-items: center;
  justify-content: space-between;
}

.checkColumnsicon {
  cursor: pointer;
}
.checkColumnsicon:hover {
  opacity: 0.8;
  background-color: rgba(102, 102, 102, 0.1);
}
</style>
