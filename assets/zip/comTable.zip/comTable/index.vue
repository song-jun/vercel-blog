<template>
  <div class="table-box" ref="table-box">
    <div ref="search">
      <slot name="search">
        <search
          v-on="$listeners"
          v-if="formData && formData.list && formData.list.length"
          :options="formData"
          :col="formData.col"
          @toToggle="toToggle"
        ></search>
      </slot>
    </div>
    <div ref="table-view" class="table-view wbgc-card">
      <div ref="toolbar" class="toolbar" :class="{ 'no-filter': showFilter }">
        <Tabs
          v-if="showFilter"
          :tabs="tableName"
          @tabChange="handleTabChange"
          :default-active-key="tableName[0] || ''"
          class="stock-bar-tab"
        >
          <template #tab="{ item }">
            <span style="margin-right: 8px">{{ item || "" }}</span>
            <CheckColumn v-model="filterColumn" :exclude="exclude" />
          </template>
        </Tabs>
        <span v-if="!showFilter || noFilter"> </span>

        <slot name="toolbar" />
      </div>
      <w-table
        class="ant-table-center"
        :data-source="dataSource"
        :row-key="rowKey"
        :pagination="false"
        :scroll="localScroll"
        :row-selection="finalRowSelection"
        :locale="locale"
        :loading="{
          spinning: loading,
          tip: '加载中',
        }"
        v-bind="$attrs"
        @change="handleChange"
      >
        <template
          v-for="(index, name) in renderSlots"
          :slot="name"
          slot-scope="row"
        >
          <slot :name="name" :row="row" />
        </template>
        <w-table-column
          v-if="showIndex"
          :title="indexTitle || '序号'"
          width="80px"
          align="left"
          fixed="left"
        >
          <template slot-scope="text, row, index">
            {{ recordnum + index + 1 }}
          </template>
        </w-table-column>
        <w-table-column
          v-for="column of columns"
          :key="column.dataIndex"
          :width="
            isFunction(column.width) ? column.width() : column.width || ''
          "
          :data-index="column.dataIndex"
          :align="column.align"
          :ellipsis="column.ellipsis || false"
          :fixed="column.fixed || false"
          :custom-render="column.customRender"
          :sorter="column.sorter"
          :sort-directions="column.sortDirections"
          :default-sort-order="column.defaultSortOrder"
        >
          <slot v-if="!column.cusTitle" :name="`${column.dataIndex}Title`">
            <span slot="title">{{
              isFunction(column.title) ? column.title() : column.title
            }}</span>
          </slot>
          <slot v-if="column.cusTitle" :name="`${column.dataIndex}Title`">
            <span slot="title" class="addBox"
              >{{ column.title
              }}<w-icon
                v-if="column.showAdd"
                class="addBtn"
                type="plus-square"
                @click="clickHead(column)"
            /></span>
          </slot>
          <template slot-scope="text, row, index">
            <slot
              :name="column.dataIndex"
              :text="text"
              :index="index"
              :row="row"
              :column="column"
              :record="row"
            >
              <EllipsisContent
                :width="getEllipsisContentWidth(column)"
                :title="
                  column.scopedSlots
                    ? column.scopedSlots.customRender
                    : row[column.dataIndex]
                "
                :column="column"
              >
                <span v-if="!column.type" :title="text">{{
                  isDef(text)
                    ? text
                    : column.defaultValue
                    ? column.defaultValue
                    : "--"
                }}</span>
                <!-- 字典值-->
                <div v-else-if="column.type === 'select'">
                  {{ getDictValue(column.dict, text) || text }}
                </div>
                <!-- 超链接 -->
                <a
                  v-else-if="column.type === 'link'"
                  @click="linkClick(row, column.dataIndex)"
                  >{{ text }}</a
                >
                <!-- cell编辑 -->
                <edit-cell
                  v-else-if="column.type === 'edit'"
                  :class="
                    (column?.tooltip?.show ?? false) || column.ellipsis
                      ? 'ell'
                      : 'noell'
                  "
                  :text="text"
                  @change="changeCell($event, row, column.dataIndex)"
                />
                <!-- 开关-->
                <w-switch
                  v-else-if="column.type === 'switch'"
                  :checked="Boolean(text)"
                  @change="changeSwitch($event, row, column.dataIndex)"
                />
                <!-- 图片-->
                <w-popover
                  v-else-if="column.type === 'img'"
                  placement="right"
                  trigger="click"
                >
                  <template slot="content">
                    <img :src="`${imgSrc}${text}`" style="max-width: 800px" />
                  </template>
                  <img
                    :src="`${imgSrc}${text}`"
                    :height="column.height || 50"
                    alt=""
                  />
                </w-popover>
                <!-- 操作列-->
                <div v-else-if="column.type === 'action'">
                  <span
                    v-for="(event, e_index) of column.events"
                    :key="event.key"
                  >
                    <component
                      :is="column.showType === 'button' ? 'w-button' : 'w'"
                      :type="event.type || 'primary'"
                      :size="event.size || 'small'"
                      :icon="event.icon || ''"
                      :disabled="event.disabled ? event.disabled(row) : false"
                      @click="handleEvent(row, event.key, e_index, index)"
                    >
                      {{ isFunction(event.name) ? event.name() : event.name }}
                    </component>
                    <w-divider
                      v-if="e_index !== column.events.length - 1"
                      type="vertical"
                    />
                  </span>
                </div>
              </EllipsisContent>
            </slot>
          </template>
        </w-table-column>
      </w-table>
      <!-- 不设置total的时候，不展示分页-->
      <div v-show="page.total > 0" ref="table-page" class="table-page">
        <div v-show="showCheckbox && showTotal" class="select-tip">
          已选择&nbsp;{{ selectedKeys.length }}&nbsp;项
        </div>
        <w-pagination
          :size="infoSize"
          v-model="page.currentPage"
          :page-size.sync="page.pageSize"
          :total="page.total"
          :page-size-options="page.pageSizeOptions || ['10', '20', '50']"
          show-size-changer
          show-less-items
          show-quick-jumper
          :show-total="(total) => getTotalText(total)"
          @change="changePage"
          @showSizeChange="changePage"
        />
      </div>
    </div>
  </div>
</template>

<script>
import _ from "lodash-es";
import EditCell from "./EditCell";
import CheckColumn from "./checkColumn";
import search from "./search";
import Tabs from "./tabs.vue";
import EllipsisContent from "./EllipsisContent.vue";

// antd 表格默认的左右padding，会影响省略时父容器的计算
const ANT_TABLE_LR_PADDING = 32;
export default {
  name: "InfoTable",
  components: { EditCell, CheckColumn, Tabs, search, EllipsisContent },
  inheritAttrs: false,
  props: {
    formData: {
      type: Object,
      default() {
        return {};
      },
    },
    infoSize: {
      type: String,
      default: "default",
    },
    columns: {
      type: Array,
      default: () => [],
    },
    dataSource: {
      type: Array,
      default: () => [],
    },
    page: {
      type: Object,
      default() {
        return {
          currentPage: 1,
          pageSize: 10,
          total: 0,
        };
      },
    },
    rowKey: {
      type: [String, Function],
      default: "id",
    },
    loading: Boolean,
    scroll: Object,
    showIndex: Boolean,
    showCheckbox: Boolean,
    showRadio: Boolean,
    showTotal: {
      type: Boolean,
      default: false,
    },
    initSelectedRowKeys: {
      type: Array,
      default() {
        return [];
      },
    },
    indexTitle: String,
    disableCheck: Array,
    disabled: {
      type: Boolean,
      default: false,
    },
    showFilter: {
      type: Boolean,
      default: true,
    },
    exclude: {
      type: Array,
      default: () => [],
    },
    rowSelection: {
      type: Object,
    },
    tableName: {
      type: Array,
      default: () => [null],
    },
    getCheckboxProps: {
      type: Function,
    },
    noFilter: {
      type: Boolean,
      default: true,
    },
  },
  data() {
    return {
      imgSrc: "",
      dictMap: {},
      selectedKeys: [...this.initSelectedRowKeys],
      selectedRows: [],
      localScroll: this.scroll,
      recordnum: 0,
      filterColumn: this.columns,
    };
  },
  computed: {
    locale() {
      if (this.loading) {
        return { emptyText: "" };
      }
      return undefined;
    },
    finalRowSelection() {
      if (this.rowSelection) {
        return this.rowSelection;
      }
      let obj = {};
      if (this.getCheckboxProps) {
        obj = { getCheckboxProps: this.getCheckboxProps };
      }
      if (this.showCheckbox) {
        return {
          fixed: true,
          selectedRowKeys: this.selectedKeys,
          onChange: this.onChangeCheckbox,
          ..._.cloneDeep(obj),
        };
      } else if (this.showRadio) {
        return {
          fixed: true,
          type: "radio",
          selectedRowKeys: this.selectedKeys,
          onChange: this.onChangeRadio,
          ...obj,
        };
      }
      return undefined;
    },
    renderSlots() {
      return this.$scopedSlots.expandedRowRender
        ? {
            expandedRowRender: this.$scopedSlots.expandedRowRender,
          }
        : null;
    },
  },
  watch: {
    scroll: {
      handler() {
        this.getScrollY();
      },
      deep: true,
    },
    page: {
      handler(page) {
        if (page.total) {
          this.$nextTick(() => {
            this.getScrollY();
          });
          if (page.total > page.pageSize) {
            const num = Math.ceil(page.total / page.pageSize);
            this.page.currentPage =
              this.page.currentPage > num ? num : this.page.currentPage;
          } else {
            this.page.currentPage = 1;
          }
        }
      },
      deep: true,
    },
    initSelectedRowKeys(val) {
      this.selectedKeys = [...val];
    },
    "initSelectedRowKeys.length": () => {
      this.selectedKeys = [...this.initSelectedRowKeys];
    },
    dataSource: {
      handler() {
        this.recordnum = (this.page.currentPage - 1) * this.page.pageSize;
      },
      immediate: true,
      deep: true,
    },
    filterColumn(val) {
      this.$emit("update:columns", val);
    },
    columns: {
      handler(newV) {
        this.filterColumn = newV;
      },
      deep: true,
    },
  },
  mounted() {
    this.imgSrc =
      (window.apiconfig || this.$serverconfig || {}).IMG_BASE_URL || "";
    this.dictMap = this.$dict?.dictMap || {};
  },
  methods: {
    // 获取省略容器真实宽度
    getEllipsisContentWidth(column) {
      let columnWidth = parseInt(column.width || 200 + ANT_TABLE_LR_PADDING);
      return columnWidth - ANT_TABLE_LR_PADDING;
    },
    toToggle() {
      this.getScrollY();
    },
    isFunction(fn) {
      return typeof fn === "function" ? true : false;
    },
    linkClick(row, key) {
      this.$emit("linkClick", row, key);
    },
    handleEvent(row, key, e_index, index) {
      this.$emit(key, row, e_index, index);
    },
    changeSwitch(checked, row, key) {
      this.$emit("changeSwitch", checked, row, key);
    },
    clickHead(column) {
      this.$emit("clickHead", column);
    },
    changeCell(text, row, key) {
      row[key] = text;
      this.$emit("changeCell", text, row, key);
    },
    changePage(current, pageSize) {
      this.$emit("changePage", current, pageSize);
    },
    getDictValue(dictCode, text) {
      let res = "";
      try {
        res = this.dictMap[dictCode][text];
      } catch {
        return text;
      }
      return res;
    },
    /**
     * selectedRowKeys是支持跨页的,selectedRows不支持跨页,所以要判断处理整合数据
     * */
    onChangeCheckbox(selectedRowKeys, selectedRows) {
      let rowKeyIsFunction = typeof this.rowKey === "function";
      // push额外的row进去
      selectedRows.forEach((row) => {
        if (rowKeyIsFunction) {
          if (
            !this.selectedRows.find(
              (item) => this.rowKey.call(item) === this.rowKey.call(row)
            )
          ) {
            this.selectedRows.push(row);
          }
        } else {
          if (
            !this.selectedRows.find(
              (item) => item[this.rowKey] === row[this.rowKey]
            )
          ) {
            this.selectedRows.push(row);
          }
        }
      });
      // 重新根据key进行筛选
      this.selectedRows = this.selectedRows.filter((row) => {
        return rowKeyIsFunction
          ? selectedRowKeys.some((key) => key === this.rowKey.call(row))
          : selectedRowKeys.includes(row[this.rowKey]);
      });
      this.selectedKeys = selectedRowKeys;
      this.$emit("changeCheckbox", selectedRowKeys, this.selectedRows);
    },
    onChangeRadio(selectedRowKeys, selectedRows) {
      this.selectedKeys = selectedRowKeys;
      this.$emit("changeRadio", selectedRowKeys, selectedRows);
    },
    // 空数据处理,0会被当成false处理
    // 需要处理 非0空数据默认显示 defaultValue --
    isDef(text) {
      if (text === undefined || text === null || String(text).trim() === "") {
        return false;
      }
      return true;
    },
    /**
     * table高度计算
     * */
    getScrollY: _.debounce(
      function () {
        if (this?.scroll?.y) {
          return;
        }
        this.$nextTick(() => {
          let tableHeaderHeight =
            this.$refs["table-view"]?.querySelector("thead")?.clientHeight || 0; // 表头高度
          let toolbarHeight = this.$refs["toolbar"]?.clientHeight || 0;
          let pageHeight = this.$refs["table-page"]?.clientHeight || 0;
          const tableHeight = this.$refs["table-box"]?.clientHeight || 0;
          let searchHeight = this.$refs["search"]?.clientHeight || 0; // 表头高度
          let height =
            tableHeight -
            toolbarHeight -
            tableHeaderHeight -
            pageHeight -
            searchHeight;
          this.localScroll = {
            y: height <= 0 ? "auto" : `${height}px`,
            ...this.scroll,
          };
        });
      },
      50,
      { leading: true }
    ),
    handleChange(pagination, filters, sorter) {
      this.$emit("change", pagination, filters, sorter);
    },
    handleTBody() {
      let tableWrapperEl =
        this.$refs["table-view"].querySelector(".wpg-table-body");
      let cssText = tableWrapperEl.style.cssText;
      let cssTextArr = cssText.split(";");
      let maxHeight = "";
      cssTextArr.forEach((item) => {
        if (item.includes("max-height")) {
          maxHeight = item.split(": ")[1];
        }
      });
      tableWrapperEl.style.height = `${tableWrapperEl.style.maxHeight}`;
    },
    handleTabChange(value) {
      this.$emit("tabChange", value);
    },
    getTotalText(total) {
      return `共${total}条`;
    },
  },
};
</script>

<style scoped lang="less">
.addBox {
  position: relative;

  .addBtn {
    position: absolute;
    right: -10px;
    bottom: -23px;
    display: none;
    font-size: 20px;
  }
}

.wpg-table-row-cell-break-word:hover {
  .addBox {
    .addBtn {
      display: block;
    }
  }
}

.wpg-table-center {
  /deep/ .wpg-table-fixed-left .wpg-table-header .wpg-table-thead tr th {
    padding-left: 30px !important;
  }

  /deep/ .wpg-table-fixed-left table tr td {
    padding-left: 30px !important;
  }
}

.table-view {
  position: relative;
  height: 100%;

  a[type="danger"] {
    color: #ff4d4f;
  }

  // 隐藏滚动条
  /deep/ .wpg-table-body {
    &::-webkit-scrollbar {
      width: 0;
      background-color: transparent;
    }
  }

  /deep/ .wpg-table-header {
    &::-webkit-scrollbar {
      width: 3px;
      background-color: transparent;
    }
  }

  /deep/ .wpg-table-tbody {
    > tr > td {
      vertical-align: middle;
    }
  }

  // 去掉未滚动时出现的滚动条占位
  /deep/ .wpg-table-body-inner {
    //覆盖内联样式
    overflow-y: auto !important;
  }

  /deep/ .wpg-table-hide-scrollbar {
    &::-webkit-scrollbar {
      min-width: 0;
    }
  }

  .table-page {
    position: absolute;
    right: 0;
    bottom: 0;
    // 要大于 .wpg-table-fixed-right fixed 定位级别
    z-index: 2;
    display: flex;
    justify-content: flex-end;
    width: 100%;
    padding: 8px 20px;

    // 去掉上一页和下一页的边框
    /deep/ .wpg-pagination-prev,
    /deep/ .wpg-pagination-next {
      border: none;
    }

    .select-tip {
      display: flex;
      flex: 1;
      align-items: center;
      font-size: 14px;
    }
  }
}

// 将不可选择的项目加上蒙层
/deep/
  .wpg-checkbox-wrapper-disabled
  .wpg-checkbox-checked
  .wpg-checkbox-inner {
  background: #4285f4 !important;
  border: 1px solid #d6d6d6 !important;
  border-radius: 4px;
  opacity: 0.6;
}

// 在黑色主题下，fix table的字体设为透明
[data-wpg-theme="dark"] {
  .table-view {
    /deep/
      .wpg-table-scroll
      table
      .wpg-table-fixed-columns-in-body:not([colspan]) {
      color: transparent;
    }
  }
}

.toolbar {
  display: flex;
  flex: 1;
  padding: 0 12px;
  align-items: center;
  height: 48px;
  justify-content: space-between;
}

.one-tab {
  /deep/ .wpg-tabs-ink-bar {
    width: 100% !important;
  }
}

.table-box {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
  .noell {
    /deep/ 
      .editable-cell-text-wrapper {
        span {
          width: 100%;
          overflow: auto;
          white-space: unset;
        }
      }
    
  }
}
</style>
