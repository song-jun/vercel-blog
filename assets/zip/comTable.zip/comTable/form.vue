<!--
 * @Description: 
 * @Version: 
 * @Autor: MrSong
 * @Date: 2023-05-22 16:52:43
 * @LastEditors: MrSong
 * @LastEditTime: 2024-07-01 10:24:31
 * @FilePath: \meter-wms-front\src\components\myTable\form.vue
 * 数据结构
formData: {
  id: Date.now(),
  layout: {
    gutter: 24,
    span: 24,
    labelCol: {
      span: 4
    },
    wrapperCol: {
      span: 20
    }
  },
  list: [
    {
      show: true,
      fieldType: 'input',
      fieldName: 'menuName',
      label: '减免金额',
      placeholder: '请输入减免金额',
      unit: '元',
      ellipsis:true,
      limit: 'num',
      disabled: (e) => {
        console.log('🚀表单数据', e);
        return false;
      },
      listeners: {
        blur: self.blurChange
      },
      attrs: {
        maxLength: 20,
        min: 0
      },
      rules: [
        {
          required: true,
          message: '请输入减免金额'
        }
      ]
    },
    {
      show: true,
      fieldType: 'input',
      fieldName: 'codeList',
      label: '编码',
      placeholder: '请输入编码',
      limit: 'num',
      fieldNameList:[{
        fieldName: 'codeOne',
        placeholder:'codeOne'
      },{
        fieldName: 'codeTwo,
        placeholder:'codeTwo'
      }]
      disabled: (e) => {
        console.log('🚀表单数据', e);
        return false;
      },
      listeners: {
        blur: self.blurChange
      },
      attrs: {
        maxLength: 20,
        min: 0
      },
      rules: [
        {
          required: true,
          message: '请输入编码'
        }
      ]
    }
  ]
}
-->

<template>
  <w-form-model
    v-if="form"
    ref="form"
    class="myForm"
    :style="`--labelWidth:${formData.layout.labelWidth || 120}px`"
    :model="form"
    :label-col="{ span: formData.layout.labelCol.span }"
    :wrapper-col="{ span: formData.layout.wrapperCol.span }"
  >
    <w-row :gutter="formData.layout.gutter">
      <w-col
        :span="formItem.layout.span"
        v-show="formItem.show"
        v-for="(formItem, index) in formData.list"
        :key="index"
      >
        <w-form-model-item
          :style="`margin:10px 0`"
          :label="formItem.label"
          :labelCol="formItem.layout.labelCol"
          :colon="!!formItem.layout.labelColon"
          :wrapperCol="formItem.layout.wrapperCol"
          :rules="formItem.rules"
          :prop="formItem.fieldName"
        >
          <slot
            v-if="formItem.fieldType === 'slot'"
            :name="formItem.slot"
            v-bind:record="form"
            v-bind:keyItem="formItem.fieldName"
          ></slot>
          <!-- 文本输入框 -->
          <template v-else-if="formItem.fieldType === 'input'">
            <div class="input-box" v-if="formItem.fieldNameList && formItem.fieldNameList.length">
              <template v-for="(inputItem, inputIndex) in formItem.fieldNameList">
                <w-input
                  v-model="form[inputItem.fieldName]"
                  :placeholder="inputItem.placeholder"
                  :disabled="typeof formItem.disabled === 'function' ? formItem.disabled(form) : formItem.disabled"
                  v-bind="inputItem.attrs || formItem.attrs"
                  v-on="inputItem.listeners || formItem.listeners"
                  @input="changListVal($event, formItem.fieldName, inputIndex, formItem.fieldNameList)"
                />
                <span v-if="inputIndex !== formItem.fieldNameList.length - 1">-</span>
              </template>
            </div>
            <w-input
              v-model="form[formItem.fieldName]"
              :placeholder="formItem.placeholder"
              :disabled="typeof formItem.disabled === 'function' ? formItem.disabled(form) : formItem.disabled"
              v-bind="formItem.attrs"
              v-on="formItem.listeners"
              v-else
            />
          </template>

          <!-- 数字输入框 -->
          <w-input-number
            v-model="form[formItem.fieldName]"
            :placeholder="formItem.placeholder"
            :disabled="typeof formItem.disabled === 'function' ? formItem.disabled(form) : formItem.disabled"
            v-bind="formItem.attrs"
            v-on="formItem.listeners"
            v-else-if="formItem.fieldType === 'inputNumber'"
          />
          <!-- 密码输入框 -->
          <w-input-password
            v-model="form[formItem.fieldName]"
            :placeholder="formItem.placeholder"
            :disabled="typeof formItem.disabled === 'function' ? formItem.disabled(form) : formItem.disabled"
            v-bind="formItem.attrs"
            v-on="formItem.listeners"
            v-else-if="formItem.fieldType === 'password'"
          />
          <!-- 文本域输入框 -->
          <w-textarea
            v-limit="formItem.limit"
            v-model="form[formItem.fieldName]"
            :placeholder="formItem.placeholder"
            :disabled="typeof formItem.disabled === 'function' ? formItem.disabled(form) : formItem.disabled"
            v-bind="formItem.attrs"
            v-on="formItem.listeners"
            v-else-if="formItem.fieldType === 'textarea'"
          />
          <!-- 下拉选择框 -->
          <w-select
            :getPopupContainer="(trigger) => trigger.parentNode || document.body"
            v-model="form[formItem.fieldName]"
            :placeholder="formItem.placeholder"
            :disabled="typeof formItem.disabled === 'function' ? formItem.disabled(form) : formItem.disabled"
            v-bind="formItem.attrs"
            v-on="formItem.listeners"
            v-else-if="formItem.fieldType === 'select'"
          >
            <w-select-option
              :value="opt[(formItem.props && formItem.props['value']) || getOptionValue(formItem)]"
              v-for="opt in formItem.options"
              :key="opt[(formItem.props && formItem.props['value']) || getOptionValue(formItem)]"
            >
              {{ opt[(formItem.props && formItem.props["label"]) || getOptionLabel(formItem)] }}
            </w-select-option>
          </w-select>
          <!-- 树选择器 -->
          <w-tree-select
            :getPopupContainer="(trigger) => trigger.parentNode || document.body"
            v-model="form[formItem.fieldName]"
            :placeholder="formItem.placeholder"
            :disabled="typeof formItem.disabled === 'function' ? formItem.disabled(form) : formItem.disabled"
            :treeData="formItem.options"
            :dropdownStyle="{ maxHeight: '50vh' }"
            v-bind="formItem.attrs"
            v-on="formItem.listeners"
            v-else-if="formItem.fieldType === 'treeSelect'"
          />
          <!-- 级联选择器 -->
          <w-cascader
            v-model="form[formItem.fieldName]"
            :placeholder="formItem.placeholder"
            :disabled="typeof formItem.disabled === 'function' ? formItem.disabled(form) : formItem.disabled"
            :options="formItem.options"
            :fieldNames="formItem.fieldNames"
            v-bind="formItem.attrs"
            v-on="formItem.listeners"
            v-else-if="formItem.fieldType === 'cascader'"
          />
          <!-- 单选组 -->
          <w-radio-group
            v-model="form[formItem.fieldName]"
            :disabled="typeof formItem.disabled === 'function' ? formItem.disabled(form) : formItem.disabled"
            :options="formItem.options"
            :fieldNames="formItem.fieldNames"
            v-bind="formItem.attrs"
            v-on="formItem.listeners"
            v-else-if="formItem.fieldType === 'radio'"
          />
          <!-- 切换按钮 -->
          <w-switch
            v-model="form[formItem.fieldName]"
            :checkedChildren="formItem.checkedChildren || '开'"
            :unCheckedChildren="formItem.unCheckedChildren || '关'"
            :disabled="typeof formItem.disabled === 'function' ? formItem.disabled(form) : formItem.disabled"
            :fieldNames="formItem.fieldNames"
            v-bind="formItem.attrs"
            v-on="formItem.listeners"
            v-else-if="formItem.fieldType === 'switch'"
          />
          <!-- 日期|日期时间选择器 -->
          <w-date-picker
            v-model="form[formItem.fieldName]"
            :show-time="formItem.showTime"
            :format="formItem.format"
            :placeholder="formItem.placeholder"
            :disabled="typeof formItem.disabled === 'function' ? formItem.disabled(form) : formItem.disabled"
            v-bind="formItem.attrs"
            v-on="formItem.listeners"
            v-else-if="formItem.fieldType === 'datePicker'"
          />
          <!-- 月选择器 -->
          <w-month-picker
            v-model="form[formItem.fieldName]"
            :format="formItem.format"
            :placeholder="formItem.placeholder"
            :disabled="typeof formItem.disabled === 'function' ? formItem.disabled(form) : formItem.disabled"
            v-bind="formItem.attrs"
            v-on="formItem.listeners"
            v-else-if="formItem.fieldType === 'monthPicker'"
          />
          <!-- 日期|日期时间范围选择器 -->
          <w-range-picker
            v-model="form[formItem.fieldName]"
            :valueFormat="formItem.valueFormat || 'YYYY-MM-DD hh:mm:ss'"
            :format="formItem.format || 'YYYY-MM-DD'"
            :placeholder="formItem.placeholder"
            :disabled="typeof formItem.disabled === 'function' ? formItem.disabled(form) : formItem.disabled"
            v-bind="formItem.attrs"
            v-on="formItem.listeners"
            v-else-if="formItem.fieldType === 'rangePicker'"
          />
          <!-- 月范围选择器 -->
          <w-range-picker
            v-model="form[formItem.fieldName]"
            :format="formItem.format || 'YYYY-MM'"
            :valueFormat="formItem.valueFormat || 'YYYY-MM'"
            :placeholder="formItem.placeholder"
            :mode="['month', 'month']"
            :disabled="typeof formItem.disabled === 'function' ? formItem.disabled(form) : formItem.disabled"
            @panelChange="handleMonthRangePanelChange(formItem.fieldName, ...arguments)"
            v-bind="formItem.attrs"
            v-on="formItem.listeners"
            v-else-if="formItem.fieldType === 'monthRangePicker'"
          />
          <div v-else class="form-item">
            <span class="value" :class="formItem.ellipsis ? 'ell' : ''">{{ form[formItem.fieldName] }}</span>
            <span class="unit" v-if="formItem.unit && form[formItem.fieldName]">{{ formItem.unit }}</span>
          </div>
        </w-form-model-item>
      </w-col>
      <template>
        <slot name="search" v-bind:record="form"></slot>
      </template>
      <template v-if="hasUplaod">
        <w-col :span="24">
          <w-divider />
        </w-col>
        <w-col :span="24">
          <w-form-model-item label="附件上传">
            <w-button icon="upload" @click="toUploadPc"> 上传文件 </w-button>
            <div class="wfs12 wfc3 tip">支持扩展名：.doc .docx .pdf .jpg...</div>
            <div class="file-show-box">
              <w-list v-if="typeFileList.length != 0" item-layout="horizontal" :data-source="typeFileList">
                <w-list-item slot="renderItem" slot-scope="item">
                  <p>{{ item.fileTypeName }}</p>
                  <div>
                    <w-upload
                      class="sub-upload"
                      :fileList="item.files"
                      list-type="picture-card"
                      :multiple="true"
                      :remove="removeEdit"
                      @preview="previewPic"
                    >
                      <div></div>
                    </w-upload>
                  </div>
                </w-list-item>
              </w-list>
            </div>
          </w-form-model-item>

          <w-modal
            class="business-charge-system-modal"
            title="文件上传"
            :visible="uploadVisible"
            :confirm-loading="uploadConfirmLoading"
            @ok="handleUploadOk"
            @cancel="handleUploadCancel"
          >
            <w-form-model
              ref="ruleForm"
              :model="fileForm"
              :label-col="{ span: 8 }"
              :wrapper-col="{ span: 16 }"
              :rules="rules"
            >
              <w-row>
                <w-col :span="24">
                  <w-form-model-item label="文件类型" prop="fileType">
                    <w-select
                      :getPopupContainer="(trigger) => trigger.parentNode || document.body"
                      v-model="fileForm.fileType"
                      placeholder="请选择文件类型"
                      @change="selectedFileType"
                    >
                      <w-select-option v-for="item in fileTypeList" :key="item.value" :value="item.value">
                        {{ item.name }}
                      </w-select-option>
                    </w-select>
                  </w-form-model-item>
                </w-col>
                <w-col :span="24">
                  <w-form-model-item label="选择文件" prop="fileListLength">
                    <w-upload
                      class="wbdc picture-wrapper"
                      list-type="picture-card"
                      :multiple="true"
                      :fileList="fileList"
                      :showUploadList="true"
                      :before-upload="beforeUpload"
                      :customRequest="customRequest"
                      :remove="uploadRemove"
                    >
                      <w-icon type="plus" />
                    </w-upload>
                  </w-form-model-item>
                </w-col>
              </w-row>
            </w-form-model>
          </w-modal>

          <w-modal
            class="business-charge-system-modal"
            :visible="previewVisible"
            :footer="null"
            @cancel="handlePreviewCancel"
          >
            <img alt="example" style="width: 100%" :src="previewImage" />
          </w-modal>
        </w-col>
        <w-col :span="24">
          <w-divider />
        </w-col>
        <w-col :span="24">
          <w-form-model-item label="备注">
            <div style="position: relative">
              <w-textarea v-model="form.customRemark" :maxLength="200" placeholder="请输入" allowClear />
              <div class="text-count">{{ form.customRemark ? form.customRemark.length : 0 }}/200</div>
            </div>
          </w-form-model-item>
        </w-col>
      </template>
    </w-row>
  </w-form-model>
</template>

<script>
import moment from "moment";
// 如果涉及到图片，解除此行
// import storage from '@/utils/storage';
const _customData = {
  genFormData(formData) {
    const _formData = {
      id: Date.now(),
      layout: {
        gutter: 24,
        span: 6,
        labelCol: {
          span: 8,
        },
        wrapperCol: {
          span: 16,
        },
      },
      list: [],
    };
    if (formData && formData.list && formData.list.length) {
      // 全局配置（约定配置，潜拷贝即可）
      _formData.layout = { ..._formData.layout, ...formData.layout };
      // 表单项
      formData.list.forEach((v, i) => {
        // 保持单向数据流，浅拷贝
        v = { ...v };
        v.layout = { ..._formData.layout, ...v.layout };
        if (~["datePicker", "monthPicker", "rangePicker", "monthRangePicker"].indexOf(v.fieldType)) {
          // 初始值格式化
          if (v.initialValue) {
            if (Array.isArray(v.initialValue)) {
              v.initialValue = v.initialValue.map((vv) => moment(vv));
            } else {
              v.initialValue = moment(v.initialValue);
            }
          }
          // 输出格式化
          if (!v.resultFormat) {
            if (v.fieldType === "monthPicker" || v.fieldType === "monthRangePicker") {
              v.resultFormat = "YYYY-MM";
            } else if (v.showTime) {
              v.resultFormat = "YYYY-MM-DD HH:mm";
            } else {
              v.resultFormat = "YYYY-MM-DD";
            }
          }
        } else if (v.fieldType === "upload") {
          // 上传控件初始化预览图
          v.previewImage = imageFullUrl(v.initialValue);
          v.loading = false;
          v.validator = v.validator || _customData.validateImage;
        } else if (v.fieldType === "cascader" || v.fieldType === "switch") {
          // 级联选择器初始化字段映射
          v.fieldNames = {
            label: "label",
            value: "value",
            children: "children",
            ...v.fieldNames,
          };
        }
        _formData.list.push(v);
      });
    }
    return _formData;
  },
};
export default {
  name: "myForm",
  model: {
    prop: "formVal",
    event: "changeFormVal",
  },
  components: {},
  props: {
    hasUplaod: {
      type: Boolean,
      default: false,
    },
    options: {
      type: Object,
      default: () => ({}),
    },
    formVal: {
      type: Object,
      default: () => ({}),
    },
  },
  data() {
    return {
      form: null,
      formData: _customData.genFormData(this.options),
      fileList: [],
      optionsObj: {},
      disabledObj: {},
      typeFileList: [],
      previewVisible: false,
      previewImage: undefined,
      uploadVisible: false,
      fileForm: {
        fileType: "",
        fileTypeName: "",
        fileListLength: undefined,
      },
      uploadConfirmLoading: false,
      rules: {
        fileType: [{ required: true, message: "请选择文件类型！" }],
        fileListLength: [{ required: true, message: "请选择文件文件" }],
      },
    };
  },
  computed: {
    fileTypes() {
      let obj = storage.get("dictionaryValue")["FILE_TYPE"] || {};
      let newObj = {};
      for (let key in obj) {
        newObj[key] = obj[key].label;
      }
      return newObj;
    },
    fileTypeList() {
      let list = [];
      for (let key in this.fileTypes) {
        let obj = {
          name: this.fileTypes[key],
          value: key,
        };
        list.push(obj);
      }
      return list;
    },
  },
  watch: {
    options: {
      deep: true,
      immediate: true,
      handler() {
        this.formData = _customData.genFormData(this.options);
        if (this.formData.list.length) {
          let form = {};
          this.formData.list.map((item) => {
            form[item.fieldName] = item.initialValue;
            if (item.fieldNameList && item.fieldNameList.length) {
              item.fieldNameList.map((inputItem) => {
                form[inputItem.fieldName] = inputItem.initialValue || item.initialValue;
              });
            }
            this.disabledObj[item.fieldName] =
              typeof item.disabled === "function" ? item.disabled(this.form) : item.disabled;
            if (item.options) {
              this.optionsObj[item.fieldName] = item.options;
            }
          });
          if (!this.form) this.form = form;
        }
      },
    },
    form: {
      deep: true,
      immediate: true,
      handler(val) {
        // console.log('🚀=>form', val);
        if (val) {
          this.$emit("changeFormVal", val);
        }
      },
    },
    formVal: {
      deep: true,
      immediate: true,
      handler(val) {
        // console.log('🚀=>formVal', val);
        if (val) {
          for (const key in this.form) {
            if (val.hasOwnProperty(key)) this.form[key] = val[key];
          }
        }
      },
    },
  },
  methods: {
    changListVal(e, name, index, nameList) {
      let val = e.target.value;
      let valList = [];
      this.$nextTick(() => {
        nameList.map((item) => {
          valList.push(this.form[item.fieldName] || "");
        });
        this.form[name] = valList.length ? valList : undefined;
      });
    },
    toUploadPc() {
      this.fileList = [];
      this.fileForm.fileType = "";
      this.fileForm.fileTypeName = "";
      this.uploadVisible = true;
    },
    getOptionValue(formItem) {
      return formItem.optionValue ? formItem.optionValue : "value";
    },
    getOptionLabel(formItem) {
      return formItem.optionLabel ? formItem.optionLabel : "label";
    },
    ok(flag) {
      let params;
      this.$refs.form.validate(async (valid) => {
        if (valid) {
          this.show = false;
          let temp = JSON.parse(JSON.stringify(this.form));
          params = temp;
          this.$emit("submit", temp);
          if (flag) this.reset();
        }
      });
      return params;
    },
    reset() {
      this.$refs.form.resetFields();
      // 上传控件重置
      this.formData.list.forEach((v) => {
        if (v.fieldNameList && v.fieldNameList.length) {
          v.fieldNameList.map((inputItem) => {
            this.form[inputItem.fieldName] = "";
          });
          this.form[v.fieldName] = undefined;
        }
        if (v.fieldType === "upload") {
          v.previewImage = imageFullUrl(v.initialValue);
          v.loading = false;
          this.form.setFields({
            [v.fieldName]: {
              errors: [],
            },
          });
        }
      });
    },
    // 月范围选择器
    handleMonthRangePanelChange(fieldName, val) {
      this.form.setFieldsValue({
        [fieldName]: val,
      });
    },
    handleUploadOk() {
      this.$refs.ruleForm.validate((valid) => {
        if (valid) {
          let itemObj = {
            key: new Date().toString(),
            ...this.fileForm,
            files: [...this.fileList],
          };
          this.typeFileList.push(itemObj);
          this.form.typeFileList = this.typeFileList;
          this.uploadVisible = false;
        } else {
          return false;
        }
      });
    },
    removeEdit(value) {
      this.typeFileList = this.typeFileList.filter((item) => {
        item.files = item.files.filter((file) => {
          return file.uid !== value.uid;
        });
        return item.files.length !== 0;
      });
      this.form.typeFileList = this.typeFileList;
    },
    beforeUpload(file) {
      console.log("🚀 ~ file: index.vue:658 ~ beforeUpload ~ file:", file);
      let isLt2M = true;
      if (file.size) {
        isLt2M = file.size / 1024 / 1024 < 10;
        if (!isLt2M) {
          this.$message.error("单个文件大小不能超过10MB！");
          return false;
        } else if (file.name && file.name.split(".")[1] === "jar") {
          this.$message.error("不能上传后缀为jar的文件！");
          return false;
        } else if (!file.type || file.type === "") {
          this.$message.error("无法识别该文件类型！");
          return false;
        } else {
          this.fileForm.fileListLength = this.fileList.length + 1;
          return true;
        }
      } else {
        let isOk = true;
        file.forEach((element) => {
          isLt2M = element.size / 1024 / 1024 < 10;
          if (!isLt2M) {
            isOk = false;
            throw new Error();
          }
          if (element.name && element.name.split(".")[1] === "jar") {
            this.$message.error("不能上传后缀为jar的文件！");
            isOk = false;
            throw new Error();
          }
          if (!element.type || element.type === "") {
            this.$message.error("无法识别该文件类型！");
            isOk = false;
            throw new Error();
          }
        });
        if (isOk) {
          this.fileForm.fileListLength = this.fileList.length + file.length;
          return true;
        } else {
          return false;
        }
      }
    },
    selectedFileType(value) {
      this.fileForm.fileTypeName = this.fileTypes[value];
    },
    customRequest(data) {
      let that = this;
      let rd = new FileReader();
      let file = data.file;
      rd.readAsDataURL(file);
      rd.onloadend = function (e) {
        that.fileList.push({
          file,
          name: file.name,
          uid: file.uid,
          url: this.result,
          status: "done",
        });
      };
    },
    uploadRemove(value) {
      this.fileList = this.fileList.filter((item) => {
        return item.uid !== value.uid;
      });
      this.fileForm.fileListLength = this.fileList.length === 0 ? undefined : this.fileList.length;
    },
    handleUploadCancel() {
      this.uploadVisible = false;
      this.fileList = [];
      this.fileForm = {
        fileType: "",
        fileTypeName: "",
      };
      this.$refs.ruleForm.clearValidate();
    },
    handlePreviewCancel() {
      this.previewVisible = false;
    },
    previewPic(file) {
      if (file.url && file.url !== "") {
        this.previewVisible = true;
        this.previewImage = file.url;
      }
    },
    handleCancel() {
      this.visible = false;
      this.typeFileList = [];
      this.form.customRemark = "";
    },
  },
};
</script>

<style scoped lang="less">
.input-box {
  display: flex;
  justify-content: space-between;
  align-items: center;
  span {
    margin: 0 8px;
  }
}
.myForm {
  .form-item {
    display: flex;
    justify-content: flex-start;
    align-items: center;
  }
  .ell {
    /* 控制显示一行，多余部分...显示，添加width属性，可以控制单行宽度 */
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
  }
  .value {
    word-break: break-all;
  }
  .unit {
    margin: 0 5px;
  }
  /deep/ .wpg-row .wpg-form-item {
    .wpg-form-item-label {
      max-width: var(--labelWidth);
    }

    .wpg-form-item-control-wrapper {
      min-width: calc(100% - var(--labelWidth));
    }
  }
  .sub-upload {
    /deep/ .wpg-upload-select-picture-card {
      width: 0;
      height: 0;
    }
  }

  .text-count {
    position: absolute;
    bottom: 8px;
    right: 15px;
    font-size: 12px;
  }
}

.picture-wrapper {
  /deep/ .wpg-upload {
    border-style: dashed;
    border-width: 1px;
    border-color: inherit;
    border-radius: 4px;
  }
}
</style>
