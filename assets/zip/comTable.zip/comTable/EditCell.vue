<template>
  <div class="editable-cell">
    <div v-if="editable" class="editable-cell-input-wrapper">
      <w-input v-model="value" @pressEnter="check" /><w-icon
        type="check"
        class="editable-cell-icon-check"
        @click="check"
      />
    </div>
    <div v-else class="editable-cell-text-wrapper">
      <span>{{ value || "" }}</span>
      <w-icon type="edit" class="editable-cell-icon" @click="editable = true" />
    </div>
  </div>
</template>

<script>
export default {
  name: "EditableCell",
  components: {},
  props: {
    text: [String, Number],
  },
  data() {
    return {
      value: this.text,
      editable: false,
    };
  },
  computed: {},
  watch: {
    text(val) {
      this.value = val;
    },
  },
  mounted() {},
  methods: {
    check() {
      this.editable = false;
      this.$emit("change", this.value);
    },
  },
};
</script>

<style scoped lang="less">
.editable-cell {
  position: relative;
}

.editable-cell-input-wrapper,
.editable-cell-text-wrapper {
  padding-right: 24px;
  display: flex;
  justify-content: flex-start;
  align-items: center;
}
.editable-cell-text-wrapper {
  padding: 5px 24px 5px 5px;
  span {
    width: 100%;
    text-overflow: ellipsis;
    overflow: hidden;
    white-space: nowrap;
  }
}

.editable-cell-icon,
.editable-cell-icon-check {
  position: absolute;
  right: 0;
  width: 20px;
  cursor: pointer;
}

.editable-cell-icon {
  display: none;
  line-height: 18px;
}

.editable-cell-icon-check {
  line-height: 28px;
}

.editable-cell:hover .editable-cell-icon {
  display: inline-block;
}

.editable-cell-icon:hover,
.editable-cell-icon-check:hover {
  color: #108ee9;
}

.editable-add-btn {
  margin-bottom: 8px;
}
</style>
