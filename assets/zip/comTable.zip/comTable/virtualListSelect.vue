<template>
  <vxe-pulldown
    style="width: 100%"
    ref="pulldownRef"
    destroy-on-close
    transfer
    @hide-panel="hidePanel"
  >
    <template #header>
      <div class="my-headdown" v-if="false">
        <vxe-button size="mini" @click="cancel">{{
          cancelText || "取消"
        }}</vxe-button>
        <vxe-button size="mini" status="primary" @click="confirm">{{
          okText || "确定"
        }}</vxe-button>
      </div>
    </template>
    <template #default>
      <vxe-input
        :style="{ width: width }"
        v-model="searchName"
        placeholder="请选择"
        @focus="focusEvent"
        @keyup="keyupEvent"
      >
        <template #suffix>
          <template v-if="!allowClear">
            <i :class="className"></i>
          </template>
          <template v-else>
            <i v-show="!clear" :class="className" @mouseenter="mouseenter"></i>
            <i
              v-show="clear"
              class="vxe-icon-error-circle"
              @mouseleave="mouseleave"
              @click="refresh"
            ></i>
          </template>
        </template>
      </vxe-input>
    </template>
    <template #dropdown>
      <vxe-list
        height="200"
        class="my-dropdown"
        :data="list"
        auto-resize
        v-if="list.length > 0"
      >
        <template #default="{ items }">
          <div
            :class="{ active: getStatus(item), 'list-item': true }"
            v-for="item in items"
            :key="item.value"
            @click="selectEvent(item)"
          >
            <div>
              <slot name="items">{{ item.label }}</slot>
            </div>
            <div v-if="getStatus(item)"><i class="vxe-icon-check"></i></div>
          </div>
        </template>
      </vxe-list>
      <vxe-list
        height="200"
        class="my-dropdown"
        :data="list"
        auto-resize
        v-else
      >
        <template #default="{ items }">
          <div class="empty">
            <slot name="empty">
              <div><i class="vxe-icon-file-txt"></i></div>
              <div>暂无数据</div>
            </slot>
          </div>
        </template>
      </vxe-list>
    </template>
  </vxe-pulldown>
</template>

<script>
// 模拟后台
const mockList = [];
function getList(size) {
  return new Promise((resolve) => {
    if (size > mockList.length) {
      for (let index = mockList.length; index < size; index++) {
        mockList.push({
          value: `${index}`,
          label: `row_${index}`,
        });
      }
    }
    resolve(mockList.slice(0, size));
  });
}
export default {
  props: {
    value: {
      default: undefined,
    },
    // 是否开启测试数据
    test: {
      type: [String, Boolean],
      default: true,
    },
    // 单选，多选模式
    mode: {
      type: String,
      default: "multiple",
    },
    // 是否开启清除
    allowClear: {
      type: [String, Boolean],
      default: true,
    },
    okText: {
      type: [String],
      default: "确定",
    },
    cancelText: {
      type: [String],
      default: "取消",
    },
    // 宽度
    width: {
      type: [String],
      default: "100%",
    },
    // 下拉数据
    dataSource: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  watch: {
    selectedList: {
      handler(newV, oldV) {
        let strList = [];
        if (newV && newV.length) {
          newV.map((m) => {
            strList.push(m.value);
          });
        }
        this.$nextTick(() => {
          this.$emit("input", strList.join(","));
        });
      },
      immediate: true,
      deep: true,
    },
    value: {
      async handler(newV, oldV) {
        await this.formatVal(newV);
      },
      immediate: true,
      deep: true,
    },
  },
  data() {
    return {
      mockData: [],
      searchName: "",
      className: "vxe-icon-arrow-down",
      list: [],
      clear: false,
      selectedList: [],
    };
  },
  created() {},
  methods: {
    init() {
      if (this.test) {
        getList(2000).then((data) => {
          this.mockData = data;
          this.list = data;
        });
      } else {
        this.mockData = this.dataSource;
        this.list = this.dataSource;
      }
    },
    async formatVal(newV) {
      if (newV) {
        await this.init();
        let targetData = JSON.parse(JSON.stringify(newV));
        let flag = Array.isArray(targetData),
          strList = [],
          selectedList = [];
        if (targetData.indexOf(",") > -1) {
          targetData = targetData.split(",");
          flag = Array.isArray(targetData);
        }
        if (flag) {
          this.mockData.map((item) => {
            targetData.map((m) => {
              if (m == item.value) {
                strList.push(item.label);
                selectedList.push(item);
              }
            });
          });
          this.searchName = strList.join(",");
          this.selectedList = selectedList;
        } else {
          this.mockData.map((item) => {
            if (item.value == newV) {
              this.searchName = item.label || undefined;
              this.selectedList = [item];
            }
          });
        }
      } else {
        this.searchName = undefined;
      }
    },
    hidePanel(e) {
      this.className = "vxe-icon-arrow-down";
      let strList = [],
        searchName = [];
      this.selectedList.map((m) => {
        strList.push(m.value);
        searchName.push(m.label);
      });
      this.searchName = searchName.join(",");
      this.$nextTick(() => {
        this.$emit("input", strList.join(","));
      });
    },
    focusEvent() {
      const $pulldown = this.$refs.pulldownRef;
      this.className = "vxe-icon-arrow-down";
      this.formatVal(this.value);
      if ($pulldown) {
        $pulldown.showPanel().then((res) => {
          this.className = "vxe-icon-arrow-up";
        });
      }
    },
    refresh() {
      this.searchName = undefined;
      this.selectedList = [];
    },
    mouseenter(e) {
      this.clear = true;
    },
    mouseleave() {
      this.clear = false;
    },
    getStatus(item, index) {
      let flag = false;
      if (this.selectedList.length) {
        this.selectedList.map((m, index) => {
          if (m.value == item.value) {
            flag = true;
          }
        });
      }
      return flag;
    },
    keyupEvent() {
      this.list = this.searchName
        ? this.mockData.filter(
            (item) =>
              item.label.indexOf(this.searchName) > -1 ||
              this.searchName.indexOf(item.label) > -1
          )
        : this.mockData;
    },
    cancel() {
      this.selectedList = [];
      const $pulldown = this.$refs.pulldownRef;
      if ($pulldown) {
        this.className = "vxe-icon-arrow-down";
        $pulldown.hidePanel().then(() => {
          this.list = this.mockData;
        });
      }
    },
    confirm() {
      const $pulldown = this.$refs.pulldownRef;
      if ($pulldown) {
        let strList = [];
        if (this.selectedList.length) {
          this.selectedList.map((item) => {
            if (item.label) strList.push(item.label);
          });
        }
        this.searchName = strList.join(",");
        this.className = "vxe-icon-arrow-down";
        $pulldown.hidePanel().then(() => {
          this.list = this.mockData;
        });
      }
    },
    selectEvent(item) {
      if (this.mode === "multiple") {
        if (this.selectedList.length) {
          let flag = false;
          this.selectedList.map((m, index) => {
            if (m.value == item.value) {
              flag = true;
              this.selectedList.splice(index, 1);
            }
          });
          if (!flag) this.selectedList.push(item);
        } else {
          this.selectedList.push(item);
        }
      } else {
        this.selectedList = [item];
        const $pulldown = this.$refs.pulldownRef;
        if ($pulldown) {
          this.searchName = item.label;
          this.className = "vxe-icon-arrow-down";
          $pulldown.hidePanel().then(() => {
            this.list = this.mockData;
          });
        }
      }
    },
  },
};
</script>
<style lang="less" scoped>
.my-dropdown,
.my-headdown {
  background: #fff;
  border: 1px solid #ddd;
}
.my-headdown {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 7px 10px;
  border-bottom: 0;
}
.my-dropdown {
  .empty {
    height: 200px;
    display: flex;
    justify-content: center;
    align-items: center;
    background: #fff;
    flex-direction: column;
    font-size: 16px;
    i {
      font-size: 27px;
    }
  }
  padding: 10px 0 10px 10px;
  .list-item {
    cursor: pointer;
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 5px;
    padding: 5px;
    i {
      cursor: pointer;
      color: #409eff;
      padding: 0 5px;
    }
  }
  .active {
    background-color: rgb(64, 158, 255, 0.5);
    color: #fff;
    i {
      color: #fff;
    }
  }
}
</style>
