<template>
  <div class="ellipsis-box">
    <w-tooltip
      :placement="column?.tooltip?.placement??'top'"
      v-if="column?.tooltip?.show ?? false"
      :title="title"
    >
      <div
        :style="`max-width: ${width}px;`"
        class="ellipsis-content"
        ref="content"
      >
        <slot></slot>
      </div>
    </w-tooltip>
    <div
      :style="`max-width: ${width}px;`"
      v-else
      class="ellipsis-content"
      ref="content"
      :title="column.ellipsis ? title : ''"
    >
      <slot></slot>
    </div>
  </div>
</template>
<script>
export default {
  name: "ellipsis-content",
  data() {
    return {
      visible: false,
    };
  },
  props: {
    width: {
      default: 200,
    },
    title: {
      default: "",
    },
    column: {
      type: Object,
      default: () => {},
    },
  },
  watch: {
    column: {
      //深度监听，可监听到对象、数组的变化,
      handler(newV, oldV) {},
      immediate: true,
      deep: true,
    },
  },
  mounted() {},
};
</script>

<style lang="less" scoped>
.ellipsis-content {
  // max-width: 200px;
  // overflow: hidden;
  // white-space: nowrap;
  // text-overflow: ellipsis;
}
</style>
