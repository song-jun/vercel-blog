<template>
  <my-table
    :columns.sync="columns"
    :data-source="dataSource"
    :formData="formData"
    :page="page"
    :tableName="['测试']"
    :scroll="{ x: '150%' }"
    :loading="tableLoading"
    row-key="name"
    show-index
    :exclude="['action', 'name']"
    @search="search"
    @changePage="onChange"
    v-on="actions"
  >
    <template #toolbar>
      <div>
        <w-button type="primary">批量采购</w-button>
        <w-divider type="vertical" />
        <w-button>test</w-button>
      </div>
    </template>
    <template #age="{ text, record, index }"> {{ text }} </template>
  </my-table>
</template>

<script>
import myTable from "../index";
import { columns, dataSource, formData } from "./mock";
export default {
  name: "TestTable",
  components: { myTable },
  data() {
    return {
      columns: [],
      dataSource: [],
      formData: {},
      tableLoading: false,
      page: {
        currentPage: 1,
        pageSize: 10,
        total: 23,
      },
      rowSelection: {
        columnTitle: "选择",
        type: "radio",
      },
      actions: {
        linkClick: this.linkClick,
        changeSwitch: this.changeSwitch,
        changeRadio: this.changeRadio,
        add: this.addRow,
        edit: this.editRow,
        del: this.delRow,
        changeCell: this.changeCell,
        changePage: this.changePage,
      },
    };
  },
  mounted() {
    this.formData = formData(this);
    this.columns = columns;
    this.getData();
  },
  methods: {
    getData() {
      this.tableLoading = true;
      this.dataSource = dataSource;
      setTimeout(() => {
        this.tableLoading = false;
      }, 2000);
    },
    onChange(page, size) {
      console.log("🚀 ~ onChange ~ page, size:", page, size);
    },
    search(e) {
      console.log("🚀 ~ search ~ e:", e);
    },
    blurChange(e) {
      console.log("🚀", e.target.value);
    },
    linkClick() {
      console.log(...arguments);
    },
    changeCell(text, row, key) {
      console.log("🚀 ~ changeCell ~ text, row, key:", text, row, key)
      this.getData();
    },
    changeSwitch(checked, row, key) {
      console.log("🚀 ~ changeSwitch ~ checked, row, key:", checked, row, key);
      row[key] = checked ? 1 : 0;
    },
    changeRadio(row) {
      console.log("changeRadio", row);
    },
    addRow(row) {
      console.log("addRow", row);
    },
    editRow(row) {
      console.log("editRow", row);
    },
    delRow(row) {
      console.log("delRow", row);
    },
    changePage() {
      console.log(this.page);
    },
  },
};
</script>

<style scoped lang="less"></style>
