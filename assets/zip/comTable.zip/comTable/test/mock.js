export const columns = [
  {
    title: "姓名",
    dataIndex: "name",
    fixed: "left",
    width: 200,
    ellipsis: true,
    tooltip: {
      show: true,
      placement: 'topLeft'
    },
  },
  {
    title: "备注",
    dataIndex: "remark",
    width: 100,
  },
  {
    title: "性别",
    dataIndex: "sex",
    width: 100,
    type: "select",
    dict: "sexCode",
  },
  {
    title: "昵称",
    dataIndex: "nick",
    width: 150,
    type: "edit",
    tooltip: {
      show: false,
      placement: 'topLeft'
    },
    ellipsis: false
  },
  {
    title: "照片",
    dataIndex: "photo",
    type: "img",
  },
  {
    title: "是否本地人",
    dataIndex: "local",
    type: "switch",
  },
  {
    title: "出生日期",
    dataIndex: "birth",
    type: "link",
  },
  {
    title: "年龄",
    dataIndex: "age",
  },
  {
    title: "操作",
    type: "action",
    showType: "button",
    dataIndex: "action",
    width: 230,
    events: [
      {
        name: "新增",
        key: "add",
      },
      {
        name: "编辑",
        key: "edit",
        icon: "edit",
      },
      {
        name: "删除",
        key: "del",
        icon: "delete",
        type: "danger",
      },
    ],
  },
];
export const dataSource = [
  {
    name: "张三",
    nick: "小逗比",
    age: 15,
    remark: '小逗比小逗比小逗比小逗比小逗比小逗比小逗比小逗比小逗比'
    , birth: "1998-02-08",
    sex: "1",
    photo: "https://www.songjun520.cn/logo.png",
    local: 0,
  },
  {
    name: "李四",
    age: 18,
    nick: "小逗比",
    sex: "2",
    birth: "1995-06-18",
    photo: "https://www.songjun520.cn/logo.png",
    local: 1,
  },
  {
    name: "张三三",
    age: 15,
    nick: "小逗比",
    birth: "1998-02-08",
    sex: "1",
    photo: "https://www.songjun520.cn/logo.png",
    local: 0,
  },
  {
    name: "李四四",
    age: 18,
    nick: "小逗比",
    sex: "2",
    birth: "1995-06-18",
    photo: "https://www.songjun520.cn/logo.png",
    local: 1,
  },
  {
    name: "张三三2",
    age: 15,
    nick: "小逗比",
    birth: "1998-02-08",
    sex: "1",
    photo: "https://www.songjun520.cn/logo.png",
    local: 0,
  },
  {
    name: "李四四2",
    age: 18,
    nick: "小逗比",
    sex: "2",
    birth: "1995-06-18",
    photo: "https://www.songjun520.cn/logo.png",
    local: 1,
  },
  {
    name: "张三三4",
    age: 15,
    nick: "小逗比",
    birth: "1998-02-08",
    sex: "1",
    photo: "https://www.songjun520.cn/logo.png",
    local: 0,
  },
  {
    name: "李四四5",
    age: 18,
    nick: "小逗比",
    sex: "2",
    birth: "1995-06-18",
    photo: "https://www.songjun520.cn/logo.png",
    local: 1,
  },
  {
    name: "张三三6",
    age: 15,
    nick: "小逗比",
    birth: "1998-02-08",
    sex: "1",
    photo: "https://www.songjun520.cn/logo.png",
    local: 0,
  },
  {
    name: "李四四6",
    age: 18,
    nick: "小逗比",
    sex: "2",
    birth: "1995-06-18",
    photo: "https://www.songjun520.cn/logo.png",
    local: 1,
  },
];

export const formData = (self) => {
  return {
    id: Date.now(),
    col: 4,
    layout: {
      gutter: 24,
      span: 24,
      labelCol: {
        span: 4,
      },
      wrapperCol: {
        span: 20,
      },
    },
    list: [
      {
        show: true,
        fieldType: "input",
        fieldName: "test1",
        label: "test1",
        placeholder: "请输入test1",
        limit: "num",
        attrs: {
          maxLength: 20,
          min: 0,
        },
      },
      {
        show: true,
        fieldType: "input",
        fieldName: "test2",
        label: "test2",
        placeholder: "请输入test2",
        limit: "num",
        attrs: {
          maxLength: 20,
          min: 0,
        },
      },
      {
        show: true,
        fieldType: "input",
        fieldName: "test3",
        label: "test3",
        placeholder: "请输入test3",
        limit: "num",
        attrs: {
          maxLength: 20,
          min: 0,
        },
      },
      {
        show: true,
        fieldType: "input",
        fieldName: "test4",
        label: "test4",
        placeholder: "请输入test4",
        limit: "num",
        attrs: {
          maxLength: 20,
          min: 0,
        },
      },
      {
        show: true,
        fieldType: "input",
        fieldName: "test5",
        label: "test5",
        placeholder: "请输入test5",
        limit: "num",
        attrs: {
          maxLength: 20,
          min: 0,
        },
      },
      {
        show: true,
        fieldType: "input",
        fieldName: "test6",
        label: "test6",
        placeholder: "请输入test6",
        limit: "num",
        attrs: {
          maxLength: 20,
          min: 0,
        },
      },
      {
        show: true,
        fieldType: "input",
        fieldName: "test7",
        label: "test7",
        placeholder: "test7",
        unit: "元",
        ellipsis: true,
        limit: "num",
        disabled: (e) => {
          // console.log("🚀表单数据", e);
          return false;
        },
        listeners: {
          blur: self.blurChange,
        },
        attrs: {
          maxLength: 20,
          min: 0,
        },
        rules: [
          {
            required: true,
            message: "请输入test7",
          },
        ],
      },
      {
        show: true,
        fieldType: "input",
        fieldName: "codeList",
        label: "编码",
        placeholder: "请输入编码",
        // limit: 'num',
        fieldNameList: [
          {
            fieldName: "codeOne",
            placeholder: "codeOne",
          },
          {
            fieldName: "codeTwo",
            placeholder: "codeTwo",
          },
        ],
        disabled: (e) => {
          // console.log("🚀表单数据", e);
          return false;
        },
        listeners: {
          blur: self.blurChange,
        },
        attrs: {
          maxLength: 20,
          min: 0,
        },
        rules: [
          {
            required: true,
            message: "请输入编码",
          },
        ],
      },
    ],
  };
};
