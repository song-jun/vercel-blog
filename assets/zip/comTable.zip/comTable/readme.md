## 通用表格组件封装，目的是提高前端开发表格的效率。示例参见 test 目录

表格 props 说明
旧的 props:columns,dataSource,rowKey,loading,scroll,rowSelection 为 a-table 原有属性

---

新的 props: page 对象, showIndex(是否显示序号)

### column 项进行了拓展

主要是添加了 type 字段，进行内部通用渲染
type 字段说明:
select 为字典值, 此条件下, column.dict 为字典 code
img 为图片, 此条件下, column.height 对应图片高度，默认是 50,
link 为超链接, 点击, 表格会抛出@linkClick 事件
switch 为开关, 点击, 表格会抛出@changeSwitch 事件
edit 为可编辑 cell，表格会抛出@changeCell 事件
action 为操作列,此条件下,column.showType 为类型(button 还是 text),column.events 是一个数组对应各种操作

### 后续会逐渐添加功能呢
