<!--  -->
<template>
  <div style="display: flex; align-items: center">
    <w-select
      :value="value"
      placeholder="请选择"
      allow-clear
      show-search
      style="width: 100%"
      :filter-option="false"
      @popupScroll="handlePopupScroll"
      @search="filterOpts"
      @blur="blur"
      @change="clickLdapOpt"
      :dropdownMatchSelectWidth="false"
    >
      <w-select-option v-for="item in datasourceList" :key="item.value" :value="item.value">
        {{ item.label }}
      </w-select-option>
      <w-select-option disabled key="" value="" v-if="spinning || datasourceList.length">
        <a href="javascript:;" style="margin-right: 15px" disabled>{{
          datasourceCount == datasourceList.length ? "已加载全部" : "加载中"
        }}</a>
        <w-spin size="small" :spinning="spinning"></w-spin>
      </w-select-option>
    </w-select>
    <w-button style="margin-left: 5px" v-if="showAdd" @click="create" type="primary">新增</w-button>
  </div>
</template>

<script>
import { MaterialInfo_List, getSpecifications } from "@/api/api";
export default {
  props: {
    value: {
      default: undefined,
      type: String,
    },
    openAdd: {
      default: false,
      type: [Boolean, String],
    },
    type: {
      default: 1,
      type: [String, Number],
    },
    defalutData: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  data() {
    return {
      spinning: false,
      searchVal: undefined,
      showAdd: false,
      // 获取数据源搜索的查询条件
      pageNo: 1, // 当前加载的页数
      pageSize: 20, // 每页加载的数据个数
      datasourceCount: 0, // 服务器返回的响应信息
      datasourceList: [], // 服务器返回的响应信息中的搜索匹配项数据
      timer: null, // 定时器，控制请求频率
    };
  },
  watch: {
    value: {
      //深度监听，可监听到对象、数组的变化,
      handler(newV) {
        this.$emit("input", newV);
        if (newV) {
          let selectItem = this.datasourceList.find((o) => {
            return o.value == newV;
          });
          this.$emit("change", selectItem);
        } else {
          this.getDatasourceList();
          this.$emit("change", {});
        }
      },
      deep: true,
    },
    defalutData: {
      //深度监听，可监听到对象、数组的变化,
      handler(newV) {
        if (newV.list) {
          this.datasourceCount = newV.total;
          this.datasourceList = newV.list;
          this.pageNo = 1;
        }
      },
      deep: true,
    },
  },
  mounted() {
    if (this.defalutData.list) {
      this.datasourceCount = this.defalutData.total;
      this.datasourceList = this.defalutData.list;
    } else {
      this.getDatasourceList();
    }
  },
  methods: {
    create() {
      let obj = {
        label: this.searchVal,
        value: this.searchVal,
      };
      let flag = false;
      this.datasourceList.map((item) => {
        if (item.value == obj.value) {
          flag = true;
        }
      });
      if (!flag) this.datasourceList.push(obj);
    },
    formatData(response,datasourceList) {
      this.datasourceCount = response.total;
      if (this.datasourceList.length <= this.datasourceCount) {
        this.datasourceList = this.datasourceList.concat(datasourceList);
      }
      this.datasourceList = this.unique(this.datasourceList, "value");
      setTimeout(() => {
        this.spinning = false;
        if (this.openAdd && this.datasourceList.length == 0) {
          let flag = false;
          this.datasourceList.map((item) => {
            if (item.label == this.searchVal) {
              flag = true;
            }
          });
          this.showAdd = !flag;
        }
      }, 500);
    },
    getMaterialInfoList() {
      MaterialInfo_List({
        isNotZero: false,
        isdisabled: false,
        textBox: this.searchVal,
        currentPage: this.pageNo,
        pageSize: this.pageSize,
        warehouseId: this.defalutData.warehouse || undefined,
      }).then((response) => {
        let datasourceList = response.records.map((item) => {
          item.label = item.materialCode + (item.materialName || "") + (item.specificationsName || "");
          item.value = item.materialCode;
          return item;
        });
        this.formatData(response, datasourceList);
      });
    },
    getSpecifications() {
      getSpecifications({
        keyword: this.searchVal,
        currentPage: this.pageNo,
        pageSize: this.pageSize,
      }).then((response) => {
        let datasourceList = response.records.map((item) => {
          item.label = item.specificationsName;
          item.value = item.specificationsCode;
          item.specificationsId = item.id;
          return item;
        });
        this.formatData(response, datasourceList);
      });
    },
    getDatasourceList() {
      this.spinning = true;
      let key = Number(this.type);
      switch (key) {
        case 1:
          // 获取材料
          this.getMaterialInfoList();
          break;
        case 2:
          // 获取型号
          this.getSpecifications();
          break;
        default:
          break;
      }
    },
    unique(arr, key) {
      for (let i = 0; i < arr.length - 1; i++) {
        for (let j = i + 1; j < arr.length; j++) {
          if (arr[i][key] == arr[j][key]) {
            arr.splice(j, 1);
            j--;
          }
        }
      }
      return arr;
    },
    // 文本框值变化时回调
    filterOpts(val) {
      this.searchVal = val;
      if (val) {
        clearTimeout(this.timer);
        this.datasourceList = [];
        this.pageNo = 1;
        this.pageSize = 20;
        this.timer = setTimeout(() => {
          this.getDatasourceList();
        }, 500);
      } else {
        this.getDatasourceList();
      }
    },
    blur(e) {
      if (!e) {
        if (this.datasourceCount != this.datasourceList.length) this.getDatasourceList();
      }
    }, // 列表滚动时加载数据
    handlePopupScroll(e) {
      const target = e.target;
      // 判断滚动条滚动到底部时才加载
      if (
        target.scrollTop + target.offsetHeight === target.scrollHeight &&
        this.pageNo * this.pageSize < this.datasourceCount
      ) {
        this.pageNo += 1;
        this.getDatasourceList();
      }
    },
    // 选中 option 调用
    clickLdapOpt(val) {
      if (!val) {
        this.pageNo = 1;
        this.datasourceList = [];
        this.searchVal = undefined;
      }
      this.$emit("input", val);
    },
  },
};
</script>
<style lang="less" scoped></style>
