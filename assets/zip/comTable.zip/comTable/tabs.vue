<template>
  <div>
    <w-tabs class="stock-bar-tab" @change="handleChange" v-bind="$attrs" :class="{ 'one-tab': tabs.length < 2 }">
      <w-tab-pane :key="item" class="table-tab" v-for="item in tabs">
        <template #tab>
          <slot name="tab" :item="item">
            <span style="margin-right: 8px">{{ item || '' }}</span>
          </slot>
        </template>
      </w-tab-pane>
    </w-tabs>
  </div>
</template>

<script>
export default {
  name: "tabs",
  components: {},
  props: {
    tabs: {
      type: Array,
      default: () => [],
    },
  },
  methods: {
    handleChange(value) {
      this.$emit("tabChange", value);
    },
  },
};
</script>
<style lang="less" scoped>
.one-tab {
  /deep/ .wpg-tabs-ink-bar {
    width: 100% !important;
  }
}
</style>
