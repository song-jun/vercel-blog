export function isFunction(fn) {
  return typeof fn === "function" ? true : false;
}
export const getTotalText = (total,lang='zh_CN') => {
  switch (lang) {
    case "en_US":
      return `${total} pieces`;
    case "zh_CN":
      return `共${total}条`;
    case "zh_TW":
      return `共${total}条`;
    default:
      break;
  }
};
