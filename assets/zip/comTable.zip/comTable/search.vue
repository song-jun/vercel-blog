<template>
  <header class="my-search-box">
    <w-row v-if="isAction" type="flex" justify="end">
      <slot name="action"></slot>
    </w-row>
    <template v-else>
      <slot name="search">
        <my-form ref="myForm" :options="formOpt" @submit="submit">
          <w-col :span="span" :offset="offset" slot="search">
            <div class="flex-end">
              <w-button class="btn-item" type="primary" @click="toSearchAllData">
                <w-icon type="ic_search" class="wpgicon icon-ic_search wfs14" />
                <span>查询</span>
              </w-button>
              <w-button class="btn-item" @click="toResetAllData">
                <w-icon type="ic_refresh" class="wpgicon icon-ic_refresh wfs14" />
                <span>重置</span>
              </w-button>
              <a @click="toToggleHeader" class="unfold" v-if="unfold">
                <span>{{ showAll ? "收起" : "展开" }}</span>
                <w-icon :type="showAll ? 'ic_expand_less' : 'ic_expand_more'" />
              </a>
            </div>
          </w-col>
        </my-form>
      </slot>
    </template>
  </header>
</template>

<script>
import myForm from "./form";
export default {
  name: "mySearch",
  components: {
    myForm,
  },
  model: {
    prop: "options",
    event: "changeColumns",
  },
  props: {
    isAction: {
      type: Boolean,
      default: false,
    },
    options: {
      type: Object,
      default: () => {
        return {
          id: Date.now(),
          layout: {
            gutter: 24,
            span: 6,
            labelCol: {
              span: 6,
            },
            wrapperCol: {
              span: 18,
            },
          },
          list: [
            {
              show: true,
              fieldType: "input",
              fieldName: "menuName",
              label: "减免金额",
              placeholder: "请输入减免金额",
              limit: "num",
              attrs: {
                maxLength: 20,
                min: 0,
              },
            },
            {
              show: true,
              fieldType: "input",
              fieldName: "menuName",
              label: "减免金额",
              placeholder: "请输入减免金额",
              limit: "num",
              attrs: {
                maxLength: 20,
                min: 0,
              },
            },
            {
              show: true,
              fieldType: "input",
              fieldName: "menuName",
              label: "减免金额",
              placeholder: "请输入减免金额",
              limit: "num",
              attrs: {
                maxLength: 20,
                min: 0,
              },
            },
            {
              show: true,
              fieldType: "input",
              fieldName: "menuName",
              label: "减免金额",
              placeholder: "请输入减免金额",
              limit: "num",
              attrs: {
                maxLength: 20,
                min: 0,
              },
            },
            {
              show: true,
              fieldType: "input",
              fieldName: "menuName",
              label: "减免金额",
              placeholder: "请输入减免金额",
              limit: "num",
              attrs: {
                maxLength: 20,
                min: 0,
              },
            },
            {
              show: true,
              fieldType: "input",
              fieldName: "menuName",
              label: "减免金额",
              placeholder: "请输入减免金额",
              limit: "num",
              attrs: {
                maxLength: 20,
                min: 0,
              },
            },
          ],
        };
      },
    },
    col: {
      type: [Number, String],
      default: 4,
    },
  },
  watch: {
    col: {
      handler(newV) {
        if (newV) {
          let col = Number(newV || 0),
            remainder = 24 % col;
          if (remainder == 0 && col) {
            this.column = col;
            this.span = 24 / col;
          } else {
            console.warn("col列数必须被24的倍数,并且大于零");
            this.column = 4;
            this.span = 6;
          }
        }
      },
      immediate: true,
      deep: true,
    },
    options: {
      handler(newV) {},
      immediate: true,
      deep: true,
    },
  },
  computed: {
    formOpt() {
      let temp = this.initColumns();
      return temp;
    },
  },
  data() {
    return {
      showAll: false,
      unfold: true,
      condition: {},
      form: null,
      offset: 0,
      span: 6,
      column: 4,
    };
  },
  mounted() {
    this.$nextTick(() => {
      this.form = this.$refs?.myForm?.form ?? null;
    });
  },
  methods: {
    // 查询
    toSearchAllData() {
      this.$refs.myForm.ok(false);
      this.showAll = true;
      this.$emit('toToggle')
    },
    submit(e) {
      this.condition = {
        ...e,
      };
      for (const key in this.condition) {
        if (!this.condition[key]) {
          this.condition[key] = "";
        }
      }
      console.log("🚀", this.condition);
      this.$emit("search", this.condition);
    },
    // 重置
    toResetAllData() {
      this.$refs.myForm.reset();
      this.condition = {};
      this.$emit("search", this.condition);
    },
    initColumns() {
      let temp = this.options;
      if (temp && temp.list && temp.list.length) {
        let leng = temp.list.length,
          // 每行显示4个,
          // 最后一个显示操作区域部分,
          // 未展开之前显示三个表单加一个操作部分
          target = this.column - 1,
          // 余数
          remainder = leng >= this.column ? leng % this.column : 0;
        // 计算offset偏移
        if (leng <= target) {
          this.offset = (target - leng) * this.span;
          this.unfold = false;
        } else if (leng > target) {
          if (this.showAll) {
            this.offset = (target - remainder) * this.span;
          } else {
            this.offset = 0;
          }
        }
        // leng为column的整倍数
        if (leng >= this.column && remainder == 0) {
          this.offset = this.span * target;
          if (this.showAll) {
            this.offset = this.span * target;
          } else {
            this.offset = 0;
          }
        }
        temp.list.map((item, index) => {
          if (index >= target) {
            item.show = false;
          } else {
            item.show = true;
          }
          if (this.showAll) item.show = true;
          if (this.form) {
            item.initialValue = this.form[item.fieldName];
          }
        });
        temp.layout.span = this.span || 6;
        this.$emit("changeColumns", temp);
        this.$nextTick(() => {
          this.$emit("toggle");
        });
      }
      return temp;
    },
    // 折叠搜索框
    toToggleHeader() {
      this.showAll = !this.showAll;
      this.initColumns()
      this.$emit('toToggle')
    },
  },
};
</script>

<style lang="less" scoped>
.my-search-box {
  width: 100%;
  height: auto;
  padding: 10px;
  margin-bottom: 0px;
  box-sizing: border-box;
}

.flex-end {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  margin: 10px 0;

  .btn-item {
    margin-right: 20px;
  }
}
</style>
