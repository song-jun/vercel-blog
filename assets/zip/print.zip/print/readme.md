## 通用打印组件封装，目的是提高前端开发表格的效率

表格 props 说明

```js
props: {
  // 打印数据
  printInfo: {
    type: Object,
    default: () => {
      list:[]
    },
  },
  // 是否展示序号
  showIndex: {
    type: Boolean,
    default: true,
  },
  // 序号
  indexTitle: {
    type: [Number, String],
    default: "序号",
  },
  // 打印标题
  title: {
    type: [Number, String],
    default: "工程材料",
  },
  // 每页多少行
  row: {
    type: Number,
    default: 14,
  },
  // table配置
  columns: {
    type: Array,
    default: () => columns,
  },
}
```

### columns支持table属性slot,与antdesgin table组件columns配置一致
