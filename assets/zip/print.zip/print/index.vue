<template>
  <div>
    <vue-easy-print tableShow ref="easyPrint">
      <div v-for="page of pages" :key="page" class="print-box">
        <h2>{{ title }}</h2>
        <slot name="header">
          <w-row class="table-header">
            <w-col :span="8">
              <span class="table-header-item">单据日期:</span>
              <span></span>
            </w-col>
            <w-col :span="8">
              <span class="table-header-item">单据编号:</span>
              <span></span>
            </w-col>
            <w-col :span="8">
              <span class="table-header-item">单据编号:</span>
              <span></span>
            </w-col>
            <w-col :span="8">
              <span class="table-header-item">接收仓库:</span>
              <span></span>
            </w-col>
          </w-row>
        </slot>
        <w-table v-if="(page - 1) * row + 1 <= printInfo.list.length"
          :dataSource="printInfo.list.slice((page - 1) * row, page * row)" :pagination="false"
          :rowKey="(record, index) => index" bordered>
          <w-table-column v-if="showIndex" :title="indexTitle || '序号'" width="80px" align="center">
            <template slot-scope="text, record, index"> {{ (page - 1) * row + index + 1 }} </template>
          </w-table-column>
          <w-table-column v-for="column of columns" :key="column.dataIndex"
            :width="isFunction(column.width) ? column.width() : column.width || ''" :data-index="column.dataIndex"
            :align="column.align" :ellipsis="column.ellipsis || false" :fixed="column.fixed || false"
            :custom-render="column.customRender" :sorter="column.sorter" :sort-directions="column.sortDirections"
            :default-sort-order="column.defaultSortOrder">
            <slot v-if="!column.cusTitle" :name="`${column.dataIndex}Title`">
              <span slot="title">{{ isFunction(column.title) ? column.title() : column.title }}</span>
            </slot>
            <template slot-scope="text, record, index">
              <slot :name="column.dataIndex" :text="text" :index="index" :row="record" :column="column" :record="row">
                {{ text }}
              </slot>
            </template>
          </w-table-column>
        </w-table>
        <div v-if="page === pages" class="footer-box">
          <slot name="footer">
            <w-row>
              <w-col :span="12">
                <span class="footer-item">制单人:</span>
                <span class="footer-item"></span>
              </w-col>
              <w-col :span="12">
                <span class="footer-item">审核人:</span>
                <span class="footer-item"></span>
              </w-col>
              <w-col :span="12">
                <span class="footer-item">部门负责人:</span>
                <span class="footer-item"></span>
              </w-col>
              <w-col :span="12">
                <span class="footer-item">分管领导:</span>
                <span class="footer-item"></span>
              </w-col>
            </w-row>
          </slot>
        </div>
      </div>
    </vue-easy-print>
  </div>
</template>

<script>
  let dataSource = [],
    printInfo = {};
  for (let index = 0; index < 100; index++) {
    let obj = {
      key: index,
      name: `test${index + 1}`,
      age: 32,
      address: "西湖区湖底公园1号",
    };
    dataSource.push(obj);
  }
  printInfo = {
    list: dataSource,
  };
  const columns = [
    {
      title: "姓名",
      dataIndex: "name",
      key: "name",
      scopedSlots: { customRender: "name" },
    },
    {
      title: "年龄",
      dataIndex: "age",
      key: "age",
      customRender: (text, record, index) => `customRender${index + 1}`,
      ellipsis: true,
    },
    {
      title: "住址",
      scopedSlots: { customRender: "address" },
      dataIndex: "address",
      key: "address",
    },
  ];
  import vueEasyPrint from "vue-easy-print";
  export default {
    components: { vueEasyPrint },
    props: {
      // 打印数据
      printInfo: {
        type: Object,
        default: () => printInfo,
      },
      // 是否展示序号
      showIndex: {
        type: Boolean,
        default: true,
      },
      // 序号
      indexTitle: {
        type: [Number, String],
        default: "序号",
      },
      // 打印标题
      title: {
        type: [Number, String],
        default: "工程材料",
      },
      // 每页多少行
      row: {
        type: Number,
        default: 14,
      },
      // table配置
      columns: {
        type: Array,
        default: () => columns,
      },
    },
    data() {
      return {
        dataSource,
        pages: 1,
      };
    },
    watch: {
      printInfo: {
        handler: function (val) {
          if (val.list) {
            let countLength = val.list.length;
            if (countLength <= 11) {
              this.pages = 1;
            } else {
              this.pages = Math.ceil(countLength / this.row);
            }
          }
          console.log(`🚀打印页数${this.pages}`, `🚀每页${this.row}行`, `printInfo数据`, val);
        },
        deep: true,
        immediate: true,
      },
    },
    mounted() { },
    methods: {
      print() {
        if (!!window.ActiveXObject || "ActiveXObject" in window) {
          // 是否ie
          this.remove_ie_header_and_footer();
        }
        this.$refs.easyPrint.print(); // 调用vue-easy-print的打印
      },
      isFunction(fn) {
        return typeof fn === "function" ? true : false;
      },
    },
  };
</script>
<style lang="less" scoped>
  .print-box {
    height: 100%;
    text-align: center;

    .table-header {
      margin: 10px 0;
      overflow: hidden;
      margin: 10px 0;
    }

    .footer-box {
      margin-top: 40px;
    }
  }

  @page {
    size: A4 portrait;
    margin: 3mm;
  }
</style>
