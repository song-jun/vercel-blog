<template>
  <div class="print-root">
    <div class="print-btn">
      <w-button type="primary" @click="doPrint"> 打印 </w-button>
    </div>
    <vue-easy-print tableShow ref="easyPrint">
      <myprint
        title="测试封装print"
        :row="15"
        :print-info="printInfo"
        :columns="columns"
      >
        <template slot="header" slot-scope="text, record, index">
          myprint
        </template>
        <template slot="address" slot-scope="text, record, index">
          address
        </template>
        <template slot="name" slot-scope="text, record, index"> name </template>
        <template slot="footer" slot-scope="text, record, index">
          footer
        </template>
      </myprint>
    </vue-easy-print>
  </div>
</template>

<script>
import vueEasyPrint from "vue-easy-print";
import myprint from "./index.vue";
import { mocdData } from "./test";

export default {
  name: "vuePrint",
  components: { vueEasyPrint, myprint },
  data() {
    return {
      printInfo: mocdData.printInfo,
      columns: mocdData.columns,
    };
  },
  methods: {
    doPrint() {
      if (!!window.ActiveXObject || "ActiveXObject" in window) {
        // 是否ie
        this.remove_ie_header_and_footer();
      }
      this.$refs.easyPrint.print(); // 调用vue-easy-print的打印
    },
  },
};
</script>
<style lang="less" scoped>
// 打印布局外部会覆盖内
// 调整打印页边距
@media print {
  @page {
    // size: auto; // 打印可选择布局纵向横向打印
    size: A4 landscape; //设置纸张及其方向 portrait：纵向；  landscape: 横向
    // margin-top: 0mm; //去掉页眉
    // margin-bottom: 0mm; //去掉页脚
  }
}
// 打印时，页面样式（字体颜色，背景色）不显示
// 给对应的颜色样式加上 !important,以及在样式中加上-webkit-print-color-adjust: exact;
</style>
